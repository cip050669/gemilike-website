# Gem Photo Color Analyzer **Pro v3.1**

Neu in v3.1 (auf Wunsch **Punkt 1 & 2**):
1) **Pinsel-Refinement für GrabCut**: FG/BG-Bürsten, Pinselgröße, Zurücksetzen – verbessert die Segmentierung.
2) **D50-Adaption (Bradford)** als präzisere Option für CIE Lab – umschaltbar (D65↔D50) in der UI.

Weiterhin enthalten: Presets, PDF-Export, Server-Analyse, sRGB↔P3, S3-Signed Links, SQLite/Prisma.

## Start
```bash
pnpm install
pnpm prisma:generate
pnpm prisma:push
pnpm dev
```
