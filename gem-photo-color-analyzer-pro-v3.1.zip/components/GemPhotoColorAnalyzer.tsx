\"use client\";
import React, { useCallback, useMemo, useRef, useState } from "react";
import type { Stats, AnalyzeOptions } from "@/lib/analyze";
import { analyzePixels } from "@/lib/analyze";

declare global { interface Window { cv: any; } }

type ColorSpace = "sRGB" | "Display-P3";
type WhiteRef = "D65" | "D50";
type BrushMode = "FG" | "BG" | "RECT";

const PRESETS: Record<string,string[]> = {
  "Saphir-Blau (royal)": ["#1A237E","#283593","#3949AB","#5C6BC0"],
  "Saphir-Blau (kalt)": ["#0F3D91","#1F5FC4","#3F7FFF","#5AA2FF"],
  "Padparadscha-ähnlich": ["#FF6F61","#FFA177","#FFC3A0","#FFD7BA"],
  "Neutralgrau": ["#6E6E6E","#808080","#909090","#A0A0A0"],
  "Firma-Beispiel": ["#006064","#0097A7","#00BCD4","#4DD0E1"]
};

export default function GemPhotoColorAnalyzer(){
  const [files, setFiles] = useState<File[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [imgUrl, setImgUrl] = useState<string|undefined>();

  const [k, setK] = useState(5);
  const [white, setWhite] = useState(true);
  const [black, setBlack] = useState(true);
  const [lowSat, setLowSat] = useState(true);
  const [smart, setSmart] = useState(true);
  const [wThr, setWThr] = useState(220);
  const [bThr, setBThr] = useState(25);
  const [sThr, setSThr] = useState(8);
  const [palette, setPalette] = useState<string[]>(PRESETS["Saphir-Blau (royal)"]);
  const [preset, setPreset] = useState<string>("Saphir-Blau (royal)");
  const [whiteRef, setWhiteRef] = useState<WhiteRef>("D65");

  const [cvReady, setCvReady] = useState(false);
  const [brushMode, setBrushMode] = useState<BrushMode>("RECT");
  const [brushSize, setBrushSize] = useState(16);
  const [isDrawing, setIsDrawing] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overRef = useRef<HTMLCanvasElement>(null);
  const rectRef = useRef<{x:number;y:number;w:number;h:number}|null>(null);
  const fgStrokes = useRef<{x:number;y:number;r:number}[]>([]);
  const bgStrokes = useRef<{x:number;y:number;r:number}[]>([]);

  const [stats, setStats] = useState<Stats|undefined>();

  const onPickMany = useCallback((list: FileList)=>{
    const arr = Array.from(list).filter(f=>f.type.startsWith("image/"));
    setFiles(arr); setActiveIndex(0); setImgUrl(arr[0]? URL.createObjectURL(arr[0]) : undefined);
    setStats(undefined);
    fgStrokes.current = []; bgStrokes.current = []; rectRef.current = null;
    const ov = overRef.current; if(ov){ ov.getContext("2d")!.clearRect(0,0,ov.width,ov.height); }
  },[]);
  const onDrop = useCallback((e: React.DragEvent)=>{ e.preventDefault(); if(e.dataTransfer.files?.length) onPickMany(e.dataTransfer.files); },[onPickMany]);
  const prevent = (e: React.DragEvent)=>{ e.preventDefault(); };

  const loadOpenCV = useCallback(async ()=>{
    if (window.cv) { setCvReady(true); return; }
    await new Promise<void>((resolve,reject)=>{
      const s=document.createElement("script"); s.src="https://docs.opencv.org/4.x/opencv.js"; s.async=true;
      s.onload=()=>resolve(); s.onerror=()=>reject(new Error("opencv load failed")); document.head.appendChild(s);
    });
    const wait = () => new Promise<void>(res=>setTimeout(res,200));
    for(let i=0;i<25 && !window.cv;i++) await wait();
    if(window.cv) setCvReady(true);
  },[]);

  function redrawOverlay(){
    const ov = overRef.current; if(!ov) return;
    const ctx = ov.getContext("2d")!; ctx.clearRect(0,0,ov.width,ov.height);
    // rect
    if(rectRef.current){
      const rc = rectRef.current; ctx.setLineDash([6,4]); ctx.lineWidth=2; ctx.strokeStyle="rgba(37,99,235,0.9)";
      ctx.strokeRect(rc.x, rc.y, rc.w, rc.h);
    }
    // strokes
    const drawDots = (arr:{x:number;y:number;r:number}[], color:string)=>{
      ctx.setLineDash([]); ctx.fillStyle=color;
      for(const s of arr){ ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI*2); ctx.fill(); }
    };
    drawDots(fgStrokes.current, "rgba(22,163,74,0.6)");   // green
    drawDots(bgStrokes.current, "rgba(239,68,68,0.6)");   // red
  }

  const pointerToCanvas = (e: React.MouseEvent<HTMLCanvasElement>)=>{
    const ov = overRef.current!; const r = ov.getBoundingClientRect();
    const x = e.clientX - r.left; const y = e.clientY - r.top;
    return { x, y };
  };

  const onDown = (e: React.MouseEvent<HTMLCanvasElement>)=>{
    setIsDrawing(true);
    const {x,y} = pointerToCanvas(e);
    if(brushMode === "RECT"){
      rectRef.current = { x, y, w:0, h:0 };
    } else {
      const arr = (brushMode==="FG"? fgStrokes.current : bgStrokes.current);
      arr.push({ x, y, r: brushSize/2 });
    }
    redrawOverlay();
  };
  const onMove = (e: React.MouseEvent<HTMLCanvasElement>)=>{
    if(!isDrawing) return;
    const {x,y} = pointerToCanvas(e);
    if(brushMode === "RECT"){
      const rc = rectRef.current!;
      rc.w = x - rc.x; rc.h = y - rc.y;
    } else {
      const arr = (brushMode==="FG"? fgStrokes.current : bgStrokes.current);
      arr.push({ x, y, r: brushSize/2 });
    }
    redrawOverlay();
  };
  const onUp = ()=>{ setIsDrawing(false); };

  const clearStrokes = ()=>{ fgStrokes.current=[]; bgStrokes.current=[]; rectRef.current=null; redrawOverlay(); };

  // local analysis with GrabCut + brush seeds + whitepoint option
  const runLocal = useCallback(async ()=>{
    if(!imgUrl) return;
    const img = await new Promise<HTMLImageElement>((res,rej)=>{ const im=new Image(); im.crossOrigin="anonymous"; im.onload=()=>res(im); im.onerror=rej; im.src=imgUrl; });
    const w0=img.width, h0=img.height; const maxEdge=512; const ratio=w0>h0? maxEdge/w0 : maxEdge/h0;
    const w=Math.max(1,Math.round(w0*ratio)), h=Math.max(1,Math.round(h0*ratio));
    const cvs=document.createElement("canvas"); cvs.width=w; cvs.height=h; const ctx=cvs.getContext("2d",{willReadFrequently:true})!; ctx.drawImage(img,0,0,w,h);
    const imgd=ctx.getImageData(0,0,w,h);

    if(canvasRef.current){ canvasRef.current.width=w; canvasRef.current.height=h; canvasRef.current.getContext("2d")!.putImageData(imgd,0,0); const ov=overRef.current; if(ov){ ov.width=w; ov.height=h; }}

    // Build alpha via GrabCut if cvReady
    let alphaFromGrab: Uint8ClampedArray | undefined = undefined;
    if(cvReady){
      const cv = window.cv;
      const src = cv.matFromImageData(imgd);
      const mask = new cv.Mat.zeros(h, w, cv.CV_8UC1);
      const bgdModel = new cv.Mat(); const fgdModel = new cv.Mat();

      // apply brush seeds to mask
      const drawSeeds = (arr:{x:number;y:number;r:number}[], value:number)=>{
        for(const s of arr){
          cv.circle(mask, new cv.Point(Math.round(s.x), Math.round(s.y)), Math.round(s.r), new cv.Scalar(value), -1);
        }
      };
      if(fgStrokes.current.length) drawSeeds(fgStrokes.current, cv.GC_FGD);
      if(bgStrokes.current.length) drawSeeds(bgStrokes.current, cv.GC_BGD);

      let mode = 0;
      if(fgStrokes.current.length || bgStrokes.current.length){
        mode = cv.GC_INIT_WITH_MASK;
      } else if(rectRef.current){
        const rc = rectRef.current;
        const rx = Math.round(Math.min(rc.x, rc.x+rc.w));
        const ry = Math.round(Math.min(rc.y, rc.y+rc.h));
        const rw = Math.round(Math.abs(rc.w));
        const rh = Math.round(Math.abs(rc.h));
        cv.grabCut(src, mask, new cv.Rect(rx,ry,rw,rh), bgdModel, fgdModel, 5, cv.GC_INIT_WITH_RECT);
      }
      if(mode === cv.GC_INIT_WITH_MASK){
        cv.grabCut(src, mask, new cv.Rect(), bgdModel, fgdModel, 5, mode);
      }

      alphaFromGrab = new Uint8ClampedArray(w*h);
      for(let i=0;i<w*h;i++){
        const v = mask.ucharPtr(Math.floor(i/w), i%w)[0];
        alphaFromGrab[i] = (v===cv.GC_FGD || v===cv.GC_PR_FGD) ? 255 : 0;
      }
      src.delete(); mask.delete(); bgdModel.delete(); fgdModel.delete();
    }

    const opts: AnalyzeOptions = { whitepoint: whiteRef };
    const res = analyzePixels(imgd as ImageData, k, {white,black,lowSat,smart,wThr,bThr,sThr}, palette, alphaFromGrab, opts);
    setStats(res);
  },[imgUrl,k,white,black,lowSat,smart,wThr,bThr,sThr,palette,cvReady,whiteRef]);

  const runServer = useCallback(async ()=>{
    const f = files[activeIndex]; if(!f) return;
    const fd = new FormData(); fd.append("file", f); fd.append("k", String(k)); fd.append("palette", JSON.stringify(palette)); fd.append("white", whiteRef);
    const res = await fetch("/api/analyze", { method:"POST", body: fd });
    const json = await res.json(); if(json?.stats){ setStats(json.stats); }
  },[files,activeIndex,k,palette,whiteRef]);

  const exportPDF = useCallback(async ()=>{
    if(!stats) return; const { jsPDF } = await import("jspdf");
    const doc = new jsPDF({ unit:"pt", format:"a4" });
    doc.setFont("helvetica","bold"); doc.text("Gem Photo Color Analysis – Report", 40, 40);
    doc.setFont("helvetica","normal");
    doc.text(`Size: ${stats.width}×${stats.height}px  Used: ${stats.usedPixels}/${stats.totalPixels}  Mask ${(stats.maskRatio*100).toFixed(1)}%`, 40, 62);
    doc.text(`K = ${stats.k}  |  Ref-weiß: ${whiteRef}`, 40, 80);
    let y=110; const sw=18;
    stats.clusters.forEach((c,i)=>{ doc.setFillColor(c.rgb[0],c.rgb[1],c.rgb[2]); doc.rect(40,y-12,sw,sw,"F"); doc.text(`${i+1}. ${c.hex}  H:${c.hsv[0].toFixed(1)} S:${c.hsv[1].toFixed(1)} V:${c.hsv[2].toFixed(1)}  share ${(c.share*100).toFixed(1)}%`, 40+sw+10, y); y+=24; });
    y+=6; doc.text(`HSV ⌀  H ${stats.hsvStats.hueMean.toFixed(1)}  S ${stats.hsvStats.satMean.toFixed(1)}  V ${stats.hsvStats.valMean.toFixed(1)}`, 40, y);
    y+=18; doc.text(`Lab ⌀  L* ${stats.labStats.Lmean.toFixed(1)}  a* ${stats.labStats.aMean.toFixed(1)}  b* ${stats.labStats.bMean.toFixed(1)}`, 40, y);
    y+=28; doc.setFont("helvetica","bold"); doc.text("ΔE Palette", 40, y); doc.setFont("helvetica","normal"); y+=10;
    const headerY = y+12; doc.text("HEX", 40, headerY); doc.text("ΔE76", 140, headerY); doc.text("ΔE2000", 210, headerY);
    y = headerY + 8;
    stats.deltas.forEach((d)=>{ y+=16; doc.text(d.hex, 40, y); doc.text(d.dE76.toFixed(2), 140, y); doc.text(d.dE2000.toFixed(2), 210, y); });
    const cvs = canvasRef.current; if(cvs){ const dataUrl = cvs.toDataURL("image/jpeg", 0.92); const iw = 360; const ih = (cvs.height/cvs.width)*iw; doc.addImage(dataUrl, "JPEG", 380, 60, iw, ih); }
    doc.save("gem-photo-color-analysis.pdf");
  },[stats, whiteRef]);

  return (
    <div className="mx-auto max-w-6xl p-6 md:p-10">
      <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-gray-900 mb-2">Edelsteinfoto – Farb-Analyse (Pro v3.1)</h1>
      <p className="text-sm text-gray-600 mb-6">GrabCut mit FG/BG-Pinsel + D50/Bradford-Option, ΔE-Presets, PDF, Server-Analyse.</p>

      <div onDrop={onDrop} onDragOver={prevent} onDragEnter={prevent} className="mb-4 rounded-2xl border-2 border-dashed p-6 text-center bg-white/50">
        <input id="files" type="file" accept="image/*" className="hidden" multiple onChange={(e)=> e.target.files && onPickMany(e.target.files)} />
        <label htmlFor="files" className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 rounded-xl border shadow-sm bg-gray-50 hover:bg-gray-100"><span>Bilder auswählen</span></label>
        <div className="mt-2 text-xs text-gray-500">oder per Drag & Drop hierher ziehen</div>
        {files.length>0 && <div className="mt-2 text-xs text-gray-600">{files.length} Datei(en) geladen</div>}
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="rounded-2xl border p-4 bg-white/60 text-sm space-y-3">
          <h3 className="font-semibold">Analyse</h3>
          <div className="flex items-center justify-between gap-3">
            <label className="min-w-28">Cluster (K)</label>
            <input type="range" min={3} max={10} value={k} onChange={(e)=>setK(parseInt(e.target.value))} className="w-full" />
            <div className="w-10 text-right font-medium">{k}</div>
          </div>
          <h4 className="font-medium mt-2">Maskierung</h4>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center gap-2"><input type="checkbox" checked={white} onChange={(e)=>setWhite(e.target.checked)} /> hell/neutral</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={black} onChange={(e)=>setBlack(e.target.checked)} /> sehr dunkel</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={lowSat} onChange={(e)=>setLowSat(e.target.checked)} /> niedrige Sätt.</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={smart} onChange={(e)=>setSmart(e.target.checked)} /> Smart Mask</label>
            <div className="col-span-2 flex items-center gap-2"><span className="w-36">Weiß-Schwelle</span><input type="range" min={180} max={250} value={wThr} onChange={(e)=>setWThr(parseInt(e.target.value))} className="w-full" /><span className="w-10 text-right">{wThr}</span></div>
            <div className="col-span-2 flex items-center gap-2"><span className="w-36">Schwarz-Schwelle</span><input type="range" min={0} max={60} value={bThr} onChange={(e)=>setBThr(parseInt(e.target.value))} className="w-full" /><span className="w-10 text-right">{bThr}</span></div>
            <div className="col-span-2 flex items-center gap-2"><span className="w-36">Sättigungs-Schwelle</span><input type="range" min={0} max={30} value={sThr} onChange={(e)=>setSThr(parseInt(e.target.value))} className="w-full" /><span className="w-10 text-right">{sThr}</span></div>
          </div>
          <h4 className="font-medium mt-2">Referenz-Weiß (Lab)</h4>
          <div className="flex items-center gap-2">
            <select value={whiteRef} onChange={(e)=>setWhiteRef(e.target.value as WhiteRef)} className="border rounded px-2 py-1">
              <option value="D65">D65 (Standard sRGB)</option>
              <option value="D50">D50 (ICC/Bradford)</option>
            </select>
          </div>
        </div>

        <div className="rounded-2xl border p-4 bg-white/60 text-sm space-y-3">
          <h3 className="font-semibold">ΔE-Palette</h3>
          <div className="flex items-center gap-2">
            <select value={preset} onChange={(e)=>{ const p = e.target.value; setPreset(p); setPalette(PRESETS[p]); }} className="border rounded px-2 py-1">
              {Object.keys(PRESETS).map(k=><option key={k} value={k}>{k}</option>)}
            </select>
          </div>
          <div className="flex flex-wrap gap-2">
            {palette.map((hx,i)=>(
              <span key={i} className="inline-flex items-center gap-1 px-2 py-1 rounded border bg-white">
                <span className="h-4 w-4 rounded border" style={{backgroundColor:hx}}/>
                <span className="text-xs">{hx}</span>
                <button onClick={()=>setPalette(p=>p.filter((_,j)=>j!==i))} className="text-xs text-red-600">✕</button>
              </span>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <input id="addhex" placeholder="#RRGGBB" className="border rounded px-2 py-1 w-28" />
            <button onClick={()=>{ const el=document.getElementById("addhex") as HTMLInputElement; const v=el.value.trim(); if(/^#?[0-9a-fA-F]{6}$/.test(v)){ const vv=v.startsWith("#")? v : "#"+v; setPalette(p=>[...p, vv]); el.value=""; } }} className="px-2 py-1 rounded border bg-white">+ Hinzufügen</button>
          </div>
        </div>

        <div className="rounded-2xl border p-4 bg-white/60 text-sm space-y-3">
          <h3 className="font-semibold">Segmentierung & Aktionen</h3>
          <div className="flex items-center gap-2">
            <button onClick={loadOpenCV} className={`px-3 py-1.5 rounded-lg border ${cvReady? 'bg-green-600 text-white':'bg-white'} shadow`}>{cvReady? "OpenCV bereit" : "OpenCV laden"}</button>
          </div>
          <div className="flex items-center gap-2">
            <label>Werkzeug</label>
            <select value={brushMode} onChange={(e)=>setBrushMode(e.target.value as BrushMode)} className="border rounded px-2 py-1">
              <option value="RECT">Rechteck (Init)</option>
              <option value="FG">Pinsel: Vordergrund</option>
              <option value="BG">Pinsel: Hintergrund</option>
            </select>
            <label className="ml-2">Pinsel</label>
            <input type="range" min={6} max={64} value={brushSize} onChange={(e)=>setBrushSize(parseInt(e.target.value))} />
            <span className="text-xs w-8 text-right">{brushSize}px</span>
            <button onClick={clearStrokes} className="ml-auto px-2 py-1 rounded border bg-white">Zurücksetzen</button>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={runLocal} disabled={!imgUrl} className="px-3 py-1.5 rounded-lg border bg-indigo-600 text-white disabled:opacity-50 shadow">Lokal analysieren</button>
            <button onClick={runServer} disabled={!files.length} className="px-3 py-1.5 rounded-lg border bg-white shadow disabled:opacity-50">Server analysieren</button>
          </div>
        </div>
      </div>

      {files.length>1 && (
        <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
          {files.map((f, i)=> (
            <button key={i} onClick={()=>{ setActiveIndex(i); setImgUrl(URL.createObjectURL(f)); setStats(undefined); fgStrokes.current=[]; bgStrokes.current=[]; rectRef.current=null; }} className={`px-3 py-1.5 rounded-lg border text-xs ${i===activeIndex? 'bg-indigo-600 text-white' : 'bg-white'}`}>{f.name}</button>
          ))}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6 items-start">
        <div className="rounded-2xl border overflow-hidden bg-white/60 relative">
          <div className="p-3 text-sm text-gray-700 flex items-center justify-between">
            <span>Vorschau • {brushMode==="RECT" ? "Rechteck ziehen" : (brushMode==="FG" ? "FG pinseln (grün)" : "BG pinseln (rot)")} • Ref-weiß: {whiteRef}</span>
            <span className="text-xs text-gray-500">Canvas {stats?.width ?? "–"}×{stats?.height ?? "–"}</span>
          </div>
          <div className="relative">
            <canvas ref={canvasRef} className="block w-full h-auto"/>
            <canvas ref={overRef} className="absolute inset-0 w-full h-full"
              onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}
            />
          </div>
        </div>

        <div className="space-y-4">
          {stats ? (
            <>
              <div className="rounded-2xl border p-4 bg-white/60 text-sm">
                <div className="flex flex-wrap gap-3">
                  <span><b>Pixels genutzt:</b> {stats.usedPixels.toLocaleString()} / {stats.totalPixels.toLocaleString()}</span>
                  <span><b>Maskiert:</b> {(stats.maskRatio*100).toFixed(1)}%</span>
                  <span><b>K:</b> {stats.k}</span>
                </div>
              </div>

              <div className="rounded-2xl border p-4 bg-white/60">
                <h3 className="font-semibold mb-3">Dominante Farben</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {stats.clusters.map((c, i)=> (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-2xl border bg-white/50 shadow-sm">
                      <div className="h-10 w-10 rounded-xl border" style={{ backgroundColor: c.hex }} />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-gray-900">{c.hex}</div>
                        <div className="text-xs text-gray-600">RGB {c.rgb.join(", ")} • HSV {c.hsv.map(v=>v.toFixed(1)).join(", ")} • Anteil {(c.share*100).toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border p-4 bg-white/60 text-sm">
                <h3 className="font-semibold mb-2">Palette – ΔE</h3>
                <div className="overflow-hidden rounded-xl border">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left">Farbe</th>
                        <th className="px-3 py-2 text-left">HEX</th>
                        <th className="px-3 py-2 text-left">ΔE76</th>
                        <th className="px-3 py-2 text-left">ΔE2000</th>
                      </tr>
                    </thead>
                    <tbody>
                      {stats.deltas.map((r,i)=>(
                        <tr key={i} className="odd:bg-white even:bg-gray-50/60">
                          <td className="px-3 py-2"><span className="inline-block h-5 w-5 rounded border" style={{backgroundColor:r.hex}}/></td>
                          <td className="px-3 py-2">{r.hex}</td>
                          <td className="px-3 py-2">{r.dE76.toFixed(2)}</td>
                          <td className="px-3 py-2">{r.dE2000.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border p-6 bg-white/60 text-sm text-gray-600">
              Noch keine Analyse. Lade ein Bild, markiere FG/BG (oder Rechteck) und klicke „Lokal analysieren“. Für DB/S3 → „Server analysieren“.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
