import Link from "next/link";
async function fetchResults() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/results`, { cache: "no-store" });
  return res.json();
}
export default async function ResultsPage() {
  const data = await fetchResults();
  return (
    <div className="mx-auto max-w-4xl p-6 md:p-10">
      <h1 className="text-2xl md:text-3xl font-bold mb-4">Gespeicherte Analysen</h1>
      <Link href="/" className="underline text-sm">← Zurück</Link>
      <div className="mt-4 space-y-3">
        {data.items?.length ? data.items.map((r:any)=>(
          <div key={r.id} className="rounded-2xl border p-4 bg-white/60">
            <div className="text-sm"><b>ID:</b> {r.id}</div>
            <div className="text-sm"><b>Dateiname:</b> {r.filename ?? "—"}</div>
            <div className="text-sm"><b>Zeitpunkt:</b> {new Date(r.createdAt).toLocaleString()}</div>
            <pre className="text-xs overflow-auto mt-2">{JSON.stringify(r.summary, null, 2)}</pre>
          </div>
        )) : (<div className="text-sm text-gray-600">Noch keine Einträge.</div>)}
      </div>
    </div>
  );
}
