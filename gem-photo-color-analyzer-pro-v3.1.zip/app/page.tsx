import GemPhotoColorAnalyzer from "../components/GemPhotoColorAnalyzer";
export default function Page() { return <GemPhotoColorAnalyzer />; }
