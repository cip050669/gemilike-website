import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  const items = await prisma.analysisResult.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json({ items });
}
export async function POST(req: Request) {
  const body = await req.json();
  const { filename, summary, blobKey } = body || {};
  const created = await prisma.analysisResult.create({
    data: { filename: filename ?? null, summary: summary ?? {}, blobKey: blobKey ?? null },
  });
  return NextResponse.json({ ok: true, id: created.id });
}
