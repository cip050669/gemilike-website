import { NextResponse } from "next/server";
import { createCanvas, loadImage } from "canvas";
import { analyzePixels } from "@/lib/analyze";
import { prisma } from "@/lib/prisma";
import { putS3 } from "@/lib/s3";
import fs from "node:fs";
import path from "node:path";
export const runtime = "nodejs";
export async function POST(req: Request) {
  const form = await req.formData();
  const file = form.get("file") as File | null;
  const paletteStr = (form.get("palette") as string | null) ?? "[]";
  const kStr = (form.get("k") as string | null) ?? "5";
  const white = (form.get("white") as string | null) === 'D50' ? 'D50' : 'D65';
  const k = Math.max(3, Math.min(10, parseInt(kStr)));
  const palette = JSON.parse(paletteStr) as string[];
  if(!file) return NextResponse.json({ error: "file missing" }, { status: 400 });
  const buf = Buffer.from(await file.arrayBuffer());
  let blobKey: string | null = null;
  const key = `uploads/${Date.now()}-${file.name}`;
  try { const s3url = await putS3(key, new Uint8Array(buf), file.type || "application/octet-stream"); if (s3url) blobKey = s3url; } catch {}
  if(!blobKey){
    try { const upDir = path.join(process.cwd(), "uploads"); fs.mkdirSync(upDir, { recursive: true }); fs.writeFileSync(path.join(upDir, `${Date.now()}-${file.name}`), buf); blobKey = `local:${file.name}`; } catch {}
  }
  const img = await loadImage(buf);
  const w0 = img.width, h0 = img.height;
  const maxEdge = 512;
  const ratio = w0>h0 ? maxEdge/w0 : maxEdge/h0;
  const w = Math.max(1, Math.round(w0*ratio));
  const h = Math.max(1, Math.round(h0*ratio));
  const cvs = createCanvas(w, h);
  const ctx = cvs.getContext("2d") as any;
  ctx.drawImage(img as any, 0, 0, w, h);
  const imgd = ctx.getImageData(0, 0, w, h);
  const stats = analyzePixels(imgd as unknown as ImageData, k, { white:true, black:true, lowSat:true, smart:true, wThr:220, bThr:25, sThr:8 }, palette.length ? palette : ["#1A237E","#283593","#3949AB","#5C6BC0"], undefined, { whitepoint: white as any });
  const created = await prisma.analysisResult.create({ data: { filename: file.name, summary: stats as any, blobKey } });
  return NextResponse.json({ ok:true, id: created.id, stats });
}
