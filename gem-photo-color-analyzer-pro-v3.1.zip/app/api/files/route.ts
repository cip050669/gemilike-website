import { NextResponse } from "next/server";
import { signGetUrl } from "@/lib/s3";
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const key = searchParams.get("key");
  if(!key) return NextResponse.json({ error: "missing key" }, { status: 400 });
  const url = await signGetUrl(key);
  if(!url) return NextResponse.json({ error: "signing unavailable" }, { status: 400 });
  return NextResponse.json({ url });
}
