import "./globals.css";
export const metadata = { title: "Gem Photo Color Analyzer Pro", description: "Upload-basiertes Farb-Analyse-Tool für Edelsteinfotos" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="de"><body className="min-h-dvh antialiased">{children}</body></html>);
}
