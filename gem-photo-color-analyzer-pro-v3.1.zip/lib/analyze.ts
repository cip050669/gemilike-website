export type Lab = { L:number;a:number;b:number };
export type Cluster = { hex:string; rgb:[number,number,number]; hsv:[number,number,number]; share:number };
export type Stats = {
  width:number;height:number;totalPixels:number;usedPixels:number;maskRatio:number;k:number;
  clusters:Cluster[];
  hsvStats:{hueMean:number;satMean:number;valMean:number;hueMedian:number;satMedian:number;valMedian:number};
  labStats:{Lmean:number;aMean:number;bMean:number;Lmedian:number;aMedian:number;bMedian:number};
  deltas:{hex:string;dE76:number;dE2000:number}[];
};

export type AnalyzeOptions = {
  whitepoint?: 'D65'|'D50';
};

export const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
export const toHex=([r,g,b]:[number,number,number])=>`#${[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('')}`;
export const hexToRgb=(hex:string):[number,number,number]=>{const h=hex.replace('#','');const v=h.length===3?h.split('').map(c=>c+c).join(''):h;const n=parseInt(v,16);return [(n>>16)&255,(n>>8)&255,n&255];};
export const luma=([r,g,b]:[number,number,number])=>0.2126*r+0.7152*g+0.0722*b;
export function rgbToHsv(r:number,g:number,b:number):[number,number,number]{r/=255;g/=255;b/=255;const max=Math.max(r,g,b),min=Math.min(r,g,b);const d=max-min;let h=0;if(d===0)h=0;else if(max===r)h=60*(((g-b)/d)%6);else if(max===g)h=60*(((b-r)/d)+2);else h=60*(((r-g)/d)+4);if(h<0)h+=360;const s=max===0?0:(d/max);const v=max;return [h,s*100,v*100];}
export const srgbToLinear=(c:number)=>{c/=255;return c<=0.04045?c/12.92:Math.pow((c+0.055)/1.055,2.4);};
export function rgbToXyz(r:number,g:number,b:number){const R=srgbToLinear(r),G=srgbToLinear(g),B=srgbToLinear(b);const x=R*0.4124564+G*0.3575761+B*0.1804375;const y=R*0.2126729+G*0.7151522+B*0.0721750;const z=R*0.0193339+G*0.1191920+B*0.9503041;return [x,y,z];}

// Bradford chromatic adaptation matrices
const M = [
  [ 0.8951, 0.2664, -0.1614 ],
  [ -0.7502, 1.7135, 0.0367 ],
  [ 0.0389, -0.0685, 1.0296 ]
];
const Minv = [
  [ 0.9869929, -0.1470543, 0.1599627 ],
  [ 0.4323053, 0.5183603, 0.0492912 ],
  [ -0.0085287, 0.0400428, 0.9684867 ]
];
const D65 = [0.95047, 1.00000, 1.08883];
const D50 = [0.96422, 1.00000, 0.82521];
function adaptBradford([x,y,z]:[number,number,number], from:[number,number,number], to:[number,number,number]):[number,number,number]{
  const cone = [
    M[0][0]*x + M[0][1]*y + M[0][2]*z,
    M[1][0]*x + M[1][1]*y + M[1][2]*z,
    M[2][0]*x + M[2][1]*y + M[2][2]*z,
  ];
  const scale = [ cone[0]*to[0]/from[0], cone[1]*to[1]/from[1], cone[2]*to[2]/from[2] ];
  const xo = Minv[0][0]*scale[0] + Minv[0][1]*scale[1] + Minv[0][2]*scale[2];
  const yo = Minv[1][0]*scale[0] + Minv[1][1]*scale[1] + Minv[1][2]*scale[2];
  const zo = Minv[2][0]*scale[0] + Minv[2][1]*scale[1] + Minv[2][2]*scale[2];
  return [xo,yo,zo];
}

export function xyzToLab(x:number,y:number,z:number, white:'D65'|'D50'='D65'){
  const Xr = white==='D65'? D65[0] : D50[0];
  const Yr = white==='D65'? D65[1] : D50[1];
  const Zr = white==='D65'? D65[2] : D50[2];
  const fx = (t:number)=> t>Math.pow(6/29,3) ? Math.cbrt(t) : (t/(3*Math.pow(6/29,2))+4/29);
  const L = 116*fx(y/Yr)-16; const a=500*(fx(x/Xr)-fx(y/Yr)); const b=200*(fx(y/Yr)-fx(z/Zr));
  return { L, a, b };
}

export function rgbToLab(r:number,g:number,b:number, white:'D65'|'D50'='D65'):Lab {
  let [x,y,z]=rgbToXyz(r,g,b);
  if(white==='D50'){
    [x,y,z] = adaptBradford([x,y,z], D65 as any, D50 as any);
  }
  return xyzToLab(x,y,z, white);
}

// ΔE
export function deltaE76(l1:Lab,l2:Lab){ const dL=l1.L-l2.L, da=l1.a-l2.a, db=l1.b-l2.b; return Math.sqrt(dL*dL+da*da+db*db); }
export function deltaE2000(l1:Lab,l2:Lab){
  const {L:L1,a:a1,b:b1}=l1, {L:L2,a:a2,b:b2}=l2;
  const kL=1,kC=1,kH=1; const C1=Math.hypot(a1,b1), C2=Math.hypot(a2,b2);
  const Cbar=(C1+C2)/2; const G=0.5*(1-Math.sqrt(Math.pow(Cbar,7)/(Math.pow(Cbar,7)+Math.pow(25,7))));
  const a1p=(1+G)*a1, a2p=(1+G)*a2; const C1p=Math.hypot(a1p,b1), C2p=Math.hypot(a2p,b2);
  const h1p=(Math.atan2(b1,a1p)*180/Math.PI+360)%360; const h2p=(Math.atan2(b2,a2p)*180/Math.PI+360)%360;
  const dLp=L2-L1; const dCp=C2p-C1p;
  let dhp=0; if(C1p*C2p===0) dhp=0; else {
    const dh=h2p-h1p; if(Math.abs(dh)<=180) dhp=dh; else dhp=dh>180? dh-360 : dh+360;
  }
  const dHp=2*Math.sqrt(C1p*C2p)*Math.sin((dhp*Math.PI/180)/2);
  const Lbar=(L1+L2)/2; const Cbarp=(C1p+C2p)/2;
  let hbarp=0; if(C1p*C2p===0) hbarp=h1p+h2p; else {
    const dh=Math.abs(h1p-h2p); if(dh<=180) hbarp=(h1p+h2p)/2; else hbarp=(h1p+h2p+360)/2; if(hbarp>=360) hbarp-=360;
  }
  const T=1-0.17*Math.cos((hbarp-30)*Math.PI/180)+0.24*Math.cos((2*hbarp)*Math.PI/180)+0.32*Math.cos((3*hbarp+6)*Math.PI/180)-0.20*Math.cos((4*hbarp-63)*Math.PI/180);
  const dRo=30*Math.exp(-((hbarp-275)/25)**2);
  const Rc=2*Math.sqrt(Math.pow(Cbarp,7)/(Math.pow(Cbarp,7)+Math.pow(25,7)));
  const Sl=1+((0.015*(Lbar-50)**2)/Math.sqrt(20+(Lbar-50)**2));
  const Sc=1+0.045*Cbarp; const Sh=1+0.015*Cbarp*T; const Rt=-Math.sin(2*(dRo*Math.PI/180))*Rc;
  return Math.sqrt(Math.pow(dLp/(kL*Sl),2)+Math.pow(dCp/(kC*Sc),2)+Math.pow(dHp/(kH*Sh),2)+Rt*(dLp/(kL*Sl))*(dCp/(kC*Sc)));
}

// Simple K-Means in RGB
export function kmeansRGB(pixels:Uint8ClampedArray,k:number,maxIter=25):Cluster[]{
  const n=Math.floor(pixels.length/4);
  const pts=new Array(n) as [number,number,number][];
  for(let i=0;i<n;i++) pts[i]=[pixels[i*4],pixels[i*4+1],pixels[i*4+2]];
  const centroids:[number,number,number][]=[];
  centroids.push(pts[Math.floor(n/3)]);
  while(centroids.length<k){
    let bestIdx=0,bestDist=-1;
    for(let i=0;i<n;i++){
      const p=pts[i]; let dmin=Infinity;
      for(const c of centroids){ const d=(p[0]-c[0])**2+(p[1]-c[1])**2+(p[2]-c[2])**2; if(d<dmin) dmin=d; }
      if(dmin>bestDist){ bestDist=dmin; bestIdx=i; }
    }
    centroids.push(pts[bestIdx]);
  }
  const labels=new Uint16Array(n);
  for(let it=0; it<maxIter; it++){
    let moved=false;
    for(let i=0;i<n;i++){
      const p=pts[i]; let bi=0; let bd=Infinity;
      for(let c=0;c<k;c++){ const cc=centroids[c]; const d=(p[0]-cc[0])**2+(p[1]-cc[1])**2+(p[2]-cc[2])**2; if(d<bd){ bd=d; bi=c; } }
      if(labels[i]!==bi){ labels[i]=bi; moved=true; }
    }
    const sum = Array.from({length:k},()=>[0,0,0,0]);
    for(let i=0;i<n;i++){ const li=labels[i]; const p=pts[i]; sum[li][0]+=p[0]; sum[li][1]+=p[1]; sum[li][2]+=p[2]; sum[li][3]++; }
    for(let c=0;c<k;c++){
      const cnt=sum[c][3]||1; centroids[c]=[
        Math.round(sum[c][0]/cnt), Math.round(sum[c][1]/cnt), Math.round(sum[c][2]/cnt)
      ];
    }
    if(!moved) break;
  }
  const counts = new Array(k).fill(0); for(let i=0;i<n;i++) counts[labels[i]]++;
  return centroids.map((c,i)=>{ const [h,s,v]=rgbToHsv(c[0],c[1],c[2]); return { rgb:c as [number,number,number], hex:toHex(c as [number,number,number]), hsv:[h,s,v], share: counts[i]/n }; }).sort((a,b)=>b.share-a.share);
}

// Main analysis: optional external alpha + whitepoint
export function analyzePixels(imgd:ImageData,k:number,mask:{white:boolean;black:boolean;lowSat:boolean;smart:boolean;wThr:number;bThr:number;sThr:number},refPalette:string[],externalAlpha?:Uint8ClampedArray, options:AnalyzeOptions = {}):Stats{
  const { data, width:w, height:h } = imgd;
  const out = new Uint8ClampedArray(w*h*4); let used=0, masked=0;
  const borders:[number,number,number][]=[];
  // sample borders for smart detection
  if(mask.smart){
    const step=Math.max(1,Math.floor(Math.min(w,h)/64));
    const sample=(x:number,y:number)=>{ const i=(y*w+x)*4; borders.push([data[i],data[i+1],data[i+2]]); };
    for(let x=0;x<w;x+=step){ sample(x,0); sample(x,h-1); }
    for(let y=0;y<h;y+=step){ sample(0,y); sample(w-1,y); }
  }
  const ignorePx=(r:number,g:number,b:number)=>{
    const [hue,sat,val]=rgbToHsv(r,g,b); const L=luma([r,g,b]);
    if(mask.white && L>mask.wThr && sat<30) return true;
    if(mask.black && L<mask.bThr) return true;
    if(mask.lowSat && sat<mask.sThr) return true;
    if(mask.smart){
      for(const [br,bg,bb] of borders){
        const [bh,bs,bv]=rgbToHsv(br,bg,bb); const dH=Math.min(Math.abs(hue-bh),360-Math.abs(hue-bh));
        const dS=Math.abs(sat-bs), dV=Math.abs(val-bv); const dL=Math.abs(L-luma([br,bg,bb]));
        if(dH<18 && dS<28 && dV<28) return true;
        if(dL<22 && sat<10) return true;
      }
    }
    return false;
  };
  for(let i=0;i<w*h;i++){
    const r=data[i*4], g=data[i*4+1], b=data[i*4+2], a=data[i*4+3];
    const ext = externalAlpha? externalAlpha[i] : 255;
    const keepByExt = ext>0;
    if(keepByExt && !ignorePx(r,g,b) && a>5){
      out[i*4]=r; out[i*4+1]=g; out[i*4+2]=b; out[i*4+3]=255; used++;
    } else {
      out[i*4]=data[i*4]; out[i*4+1]=data[i*4+1]; out[i*4+2]=data[i*4+2]; out[i*4+3]=80; masked++;
    }
  }
  // collect kept
  const keep = new Uint8ClampedArray(used*4); for(let i=0,j=0;i<w*h;i++){ if(out[i*4+3]===255){ keep[j++]=out[i*4]; keep[j++]=out[i*4+1]; keep[j++]=out[i*4+2]; keep[j++]=255; } }
  const clusters = kmeansRGB(keep, k);
  const hues:number[]=[], sats:number[]=[], vals:number[]=[]; const Ls:number[]=[], As:number[]=[], Bs:number[]=[], white = options.whitepoint ?? 'D65';
  for(let i=0;i<keep.length;i+=4){
    const [h1,s1,v1]=rgbToHsv(keep[i],keep[i+1],keep[i+2]); hues.push(h1); sats.push(s1); vals.push(v1);
    const lab=rgbToLab(keep[i],keep[i+1],keep[i+2], white); Ls.push(lab.L); As.push(lab.a); Bs.push(lab.b);
  }
  const sorted=(a:number[])=>a.slice().sort((x,y)=>x-y); const med=(a:number[])=>{ const s=sorted(a); const m=Math.floor(s.length/2); return s.length%2?s[m]:(s[m-1]+s[m])/2; }; const mean=(a:number[])=>a.reduce((A,b)=>A+b,0)/Math.max(1,a.length);
  const meanLab:Lab={L:mean(Ls),a:mean(As),b:mean(Bs)};
  const deltas = (refPalette||[]).map(hex=>{ const [r,g,b]=hexToRgb(hex); const lab=rgbToLab(r,g,b, white); return { hex, dE76: deltaE76(meanLab, lab), dE2000: deltaE2000(meanLab, lab) }; }).sort((a,b)=>a.dE2000-b.dE2000);
  return {
    width:w, height:h, totalPixels:w*h, usedPixels:used, maskRatio:masked/(w*h), k, clusters,
    hsvStats:{ hueMean:mean(hues), satMean:mean(sats), valMean:mean(vals), hueMedian:med(hues), satMedian:med(sats), valMedian:med(vals) },
    labStats:{ Lmean:mean(Ls), aMean:mean(As), bMean:mean(Bs), Lmedian:med(Ls), aMedian:med(As), bMedian:med(Bs) },
    deltas
  };
}
