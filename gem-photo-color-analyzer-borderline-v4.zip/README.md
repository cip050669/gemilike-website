# Gem Photo Color Analyzer — Borderline Pro (v2)

**Neu umgesetzt (alle 4 Punkte):**
1) **K-Means++** & **Auto-K via GMM (diagonal) + BIC** – stabile Clusterzahl 3–8.
2) **SLIC-Superpixel** + **Guided Filter** zur Masken-Verfeinerung (smoother, weniger Randkontamination).
3) **ICC-Profil-Upload** (minimaler Parser für `wtpt`, `rXYZ/gXYZ/bXYZ`) + **D50 (Bradford)**-Umschaltung.
4) **JSON / CSV / PDF**-Export des **Borderline-Reports** (inkl. Parameter-Block).

## Start
```bash
pnpm install
pnpm dev
# http://localhost:3000
```

## Tipps
- Auto-K wählt die Anzahl der Farbmassen datengetrieben (BIC). Bei komplexen Bildern kannst du Auto-K deaktivieren und K manuell setzen.
- SLIC-Parameter: **Step** (Superpixel-Größe), **m** (Farbe vs. Raum). Größerer m → stärker kantenfolgend.
- Guided-Filter: **r** (Radius), **eps** (Regularisierung). Höherer r → glattere Maske.
- ICC: Falls `wtpt` vorhanden, wird der Weißpunkt in die Lab-Berechnung übernommen. Ohne ICC → D65 (oder D50 via Toggle).

> Hinweis: Der ICC-Parser ist minimal und extrahiert primär Weißpunkt und RGB-Colorant-XYZ. Vollständige LUTs/VCGT etc. werden nicht ausgewertet.

## Serverseitige Analyse-API
- POST `/api/analyze` (multipart/form-data)
- Felder: `file` (Bild), `options` (JSON: { scale, maskWhite, ... , algo: 'auto'|'kmeans'|'gmm', k })
- Implementiert: Maskierung, K-Means++ und GMM (diag) mit BIC; Rückgabe: JSON Analysis


### Batch-API
- POST `/api/analyze/batch` (multipart/form-data)
- Felder: wiederholt `files` + einmal `options` (JSON)
- Response: ZIP mit JSON pro Datei, `previews/` PNGs und `summary.csv`
