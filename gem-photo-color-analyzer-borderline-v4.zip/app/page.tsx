import GemPhotoColorAnalyzer from "../components/GemPhotoColorAnalyzer";
export default function Page(){ return <div className="p-6"><GemPhotoColorAnalyzer/></div>; }