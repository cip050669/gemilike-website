export const metadata = { title: "Gem Photo Color Analyzer Pro", description: "Borderline-aware color analysis for gemstone photos" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}