import { NextRequest, NextResponse } from "next/server";
import sharp from "sharp";

type Lab = { L:number; a:number; b:number };
type Cluster = { hex:string; rgb:[number,number,number]; hsv:[number,number,number]; share:number };

// ---------- utils ----------
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const toHex=([r,g,b]:[number,number,number])=>`#${[r,g,b].map(v=>v.toString(16).padStart(2,"0")).join("")}`;
function rgbToHsv(r:number,g:number,b:number):[number,number,number]{ r/=255; g/=255; b/=255; const max=Math.max(r,g,b), min=Math.min(r,g,b); const d=max-min;
  let h=0; if(d===0)h=0; else if(max===r)h=60*(((g-b)/d)%6); else if(max===g)h=60*(((b-r)/d)+2); else h=60*(((r-g)/d)+4); if(h<0)h+=360;
  const s=max===0?0:(d/max); const v=max; return [h,s*100,v*100];
}
function luma([r,g,b]:[number,number,number]){ return 0.2126*r+0.7152*g+0.0722*b; }

function srgbToLinear(c:number){ c/=255; return c<=0.04045? c/12.92 : Math.pow((c+0.055)/1.055,2.4); }
function rgbToXyz(r:number,g:number,b:number){ const R=srgbToLinear(r),G=srgbToLinear(g),B=srgbToLinear(b);
  const x=R*0.4124564+G*0.3575761+B*0.1804375; const y=R*0.2126729+G*0.7151522+B*0.0721750; const z=R*0.0193339+G*0.1191920+B*0.9503041; return [x,y,z];
}
function xyzToLab(x:number,y:number,z:number, wp:[number,number,number]=[0.95047,1.0,1.08883]){ const [Xr,Yr,Zr]=wp; const fx=(t:number)=>t>Math.pow(6/29,3)?Math.cbrt(t):(t/(3*Math.pow(6/29,2))+4/29);
  const L=116*fx(y/Yr)-16; const a=500*(fx(x/Xr)-fx(y/Yr)); const b=200*(fx(y/Yr)-fx(z/Zr)); return {L,a,b};
}
function rgbToLab(r:number,g:number,b:number, wp:[number,number,number]=[0.95047,1.0,1.08883]):Lab{ const [x,y,z]=rgbToXyz(r,g,b); return xyzToLab(x,y,z, wp); }
function deltaE76(l1:Lab,l2:Lab){ const dL=l1.L-l2.L, da=l1.a-l2.a, db=l1.b-l2.b; return Math.sqrt(dL*dL+da*da+db*db); }
function deltaE2000(l1:Lab,l2:Lab){
  const {L:L1,a:a1,b:b1}=l1,{L:L2,a:a2,b:b2}=l2; const kL=1,kC=1,kH=1; const C1=Math.hypot(a1,b1),C2=Math.hypot(a2,b2);
  const Cbar=(C1+C2)/2; const G=0.5*(1-Math.sqrt(Math.pow(Cbar,7)/(Math.pow(Cbar,7)+Math.pow(25,7))));
  const a1p=(1+G)*a1,a2p=(1+G)*a2; const C1p=Math.hypot(a1p,b1),C2p=Math.hypot(a2p,b2);
  const h1p=(Math.atan2(b1,a1p)*180/Math.PI+360)%360, h2p=(Math.atan2(b2,a2p)*180/Math.PI+360)%360;
  const dLp=L2-L1,dCp=C2p-C1p; let dhp=0; if(C1p*C2p!==0){ const dh=h2p-h1p; dhp=Math.abs(dh)<=180?dh:(dh>180?dh-360:dh+360); }
  const dHp=2*Math.sqrt(C1p*C2p)*Math.sin((dhp*Math.PI/180)/2);
  const Lbar=(L1+L2)/2,Cbarp=(C1p+C2p)/2; let hbarp=0; if(C1p*C2p===0) hbarp=h1p+h2p; else { const dh=Math.abs(h1p-h2p); hbarp=(dh<=180?(h1p+h2p)/2:(h1p+h2p+360)/2); if(hbarp>=360) hbarp-=360; }
  const T=1-0.17*Math.cos((hbarp-30)*Math.PI/180)+0.24*Math.cos((2*hbarp)*Math.PI/180)+0.32*Math.cos((3*hbarp+6)*Math.PI/180)-0.20*Math.cos((4*hbarp-63)*Math.PI/180);
  const dRo=30*Math.exp(-((hbarp-275)/25)**2); const Rc=2*Math.sqrt(Math.pow(Cbarp,7)/(Math.pow(Cbarp,7)+Math.pow(25,7)));
  const Sl=1+((0.015*(Lbar-50)**2)/Math.sqrt(20+(Lbar-50)**2)); const Sc=1+0.045*Cbarp; const Sh=1+0.015*Cbarp*T; const Rt=-Math.sin(2*(dRo*Math.PI/180))*Rc;
  return Math.sqrt(Math.pow(dLp/(kL*Sl),2)+Math.pow(dCp/(kC*Sc),2)+Math.pow(dHp/(kH*Sh),2)+Rt*(dLp/(kL*Sl))*(dCp/(kC*Sc)));
}

// ---------- KMeans++ ----------
function kmeansPlusPlusInit(points:number[][], k:number){
  const n=points.length, centroids:number[][]=[];
  centroids.push(points[Math.floor(Math.random()*n)]);
  const dist2 = (p:number[], c:number[])=> (p[0]-c[0])**2+(p[1]-c[1])**2+(p[2]-c[2])**2;
  while(centroids.length<k){
    const ds = points.map(p=> Math.min(...centroids.map(c=>dist2(p,c))));
    const sum = ds.reduce((a,b)=>a+b,0); let r=Math.random()*sum, idx=0;
    for(let i=0;i<n;i++){ r -= ds[i]; if(r<=0){ idx=i; break; } }
    centroids.push(points[idx]);
  }
  return centroids;
}
function kmeansRGB(points:number[][],k:number,maxIter=25):Cluster[]{
  const n=points.length;
  let centroids = kmeansPlusPlusInit(points, k);
  const labels=new Uint16Array(n);
  for(let it=0;it<maxIter;it++){
    let moved=false;
    for(let i=0;i<n;i++){ const p=points[i]; let bi=0, bd=Infinity; for(let c=0;c<k;c++){ const cc=centroids[c]; const d=(p[0]-cc[0])**2+(p[1]-cc[1])**2+(p[2]-cc[2])**2; if(d<bd){ bd=d; bi=c; } } if(labels[i]!==bi){ labels[i]=bi; moved=true; } }
    const sum=Array.from({length:k},()=>[0,0,0,0]);
    for(let i=0;i<n;i++){ const li=labels[i], p=points[i]; sum[li][0]+=p[0]; sum[li][1]+=p[1]; sum[li][2]+=p[2]; sum[li][3]++; }
    for(let c=0;c<k;c++){ const cnt=sum[c][3]||1; centroids[c]=[Math.round(sum[c][0]/cnt),Math.round(sum[c][1]/cnt),Math.round(sum[c][2]/cnt)]; }
    if(!moved) break;
  }
  const counts=new Array(k).fill(0); for(let i=0;i<n;i++) counts[labels[i]]++;
  const cl:Cluster[] = centroids.map((c,i)=>{ const hsv=rgbToHsv(c[0],c[1],c[2]); return {rgb:c as [number,number,number],hex:toHex(c as any),hsv,share:counts[i]/n}; }).sort((a,b)=>b.share-a.share);
  return cl;
}

// ---------- GMM diag + BIC ----------
function gmmDiagBIC(points:number[][], Kmin=3, Kmax=8, iters=20){
  const X=points, n=X.length, d=3;
  function em(k:number){
    let means=kmeansPlusPlusInit(X,k).map(c=>c.slice());
    let weights=Array(k).fill(1/k);
    let vars=Array.from({length:k},()=>Array(d).fill(4000));
    const resp=Array.from({length:n},()=>Array(k).fill(0));
    for(let it=0;it<iters;it++){
      for(let i=0;i<n;i++){
        let sumr=0;
        for(let j=0;j<k;j++){
          let p=1;
          for(let t=0;t<d;t++){
            const diff=X[i][t]-means[j][t];
            const v=vars[j][t];
            p*=Math.exp(-0.5*diff*diff/v)/Math.sqrt(2*Math.PI*v);
          }
          resp[i][j]=weights[j]*p; sumr+=resp[i][j];
        }
        if(sumr===0){ for(let j=0;j<k;j++) resp[i][j]=1/k; } else { for(let j=0;j<k;j++) resp[i][j]/=sumr; }
      }
      for(let j=0;j<k;j++){
        let Nj=0; const mu=[0,0,0];
        for(let i=0;i<n;i++){ Nj+=resp[i][j]; mu[0]+=resp[i][j]*X[i][0]; mu[1]+=resp[i][j]*X[i][1]; mu[2]+=resp[i][j]*X[i][2]; }
        mu[0]/=Nj; mu[1]/=Nj; mu[2]/=Nj; means[j]=mu.slice();
        const v=[0,0,0];
        for(let i=0;i<n;i++){ v[0]+=resp[i][j]*(X[i][0]-mu[0])**2; v[1]+=resp[i][j]*(X[i][1]-mu[1])**2; v[2]+=resp[i][j]*(X[i][2]-mu[2])**2; }
        v[0]/=Nj; v[1]/=Nj; v[2]/=Nj; vars[j]=v.map(x=>Math.max(50,x));
        weights[j]=Nj/n;
      }
    }
    let ll=0;
    for(let i=0;i<n;i++){
      let s=0;
      for(let j=0;j<k;j++){
        let p=1;
        for(let t=0;t<d;t++){
          const diff=X[i][t]-means[j][t], v=vars[j][t];
          p*=Math.exp(-0.5*diff*diff/v)/Math.sqrt(2*Math.PI*v);
        }
        s+=weights[j]*p;
      }
      ll+=Math.log(Math.max(1e-12,s));
    }
    const params=k*(d+d)+(k-1);
    const bic=-2*ll + params*Math.log(n);
    return { means, vars, weights, bic, ll, k };
  }
  let best:any=null;
  for(let k=Kmin;k<=Kmax;k++){ const run=em(k); if(!best || run.bic<best.bic) best=run; }
  return best;
}

// ---------- SLIC Superpixels (simplified) ----------
function slicSuperpixels(width:number, height:number, data:Uint8Array, step=16, m=10){
  const S=step;
  const clusters:number[][]=[];
  const labels = new Int32Array(width*height).fill(-1);
  const dists = new Float32Array(width*height).fill(Infinity);

  function colorAtIndex(idx:number){ return [data[idx],data[idx+1],data[idx+2]] as [number,number,number]; }
  function l2(a:number[],b:number[]){ return Math.hypot(a[0]-b[0], a[1]-b[1], a[2]-b[2]); }

  for(let y=S/2; y<height; y+=S){
    for(let x=S/2; x<width; x+=S){
      const i=(Math.floor(y)*width+Math.floor(x))*3;
      const rgb=colorAtIndex(i);
      clusters.push([x,y,rgb[0],rgb[1],rgb[2]]); // x,y,r,g,b
    }
  }
  const nc=clusters.length;
  const iter=5;
  for(let it=0; it<iter; it++){
    for(let ci=0; ci<nc; ci++){
      const cx=clusters[ci][0], cy=clusters[ci][1];
      for(let y=Math.max(0,Math.floor(cy-S)); y<Math.min(height,Math.floor(cy+S)); y++){
        for(let x=Math.max(0,Math.floor(cx-S)); x<Math.min(width,Math.floor(cx+S)); x++){
          const i=(y*width+x)*3;
          const dc=l2(colorAtIndex(i),[clusters[ci][2],clusters[ci][3],clusters[ci][4]]);
          const ds=Math.hypot(x-cx,y-cy);
          const D=Math.sqrt(dc*dc + (ds/S)*(ds/S)*m*m);
          const pos=y*width+x;
          if(D<dists[pos]){ dists[pos]=D; labels[pos]=ci; }
        }
      }
    }
    const acc = Array.from({length:nc},()=>[0,0,0,0,0,0]); // x,y,r,g,b,count
    for(let y=0;y<height;y++){ for(let x=0;x<width;x++){ const li=labels[y*width+x]; if(li<0) continue; const i=(y*width+x)*3; acc[li][0]+=x; acc[li][1]+=y; acc[li][2]+=data[i]; acc[li][3]+=data[i+1]; acc[li][4]+=data[i+2]; acc[li][5]+=1; } }
    for(let ci=0; ci<nc; ci++){ const c=acc[ci]; const N=Math.max(1,c[5]); clusters[ci]=[c[0]/N,c[1]/N,c[2]/N,c[3]/N,c[4]/N]; }
    dists.fill(Infinity);
  }
  return { labels, clusters };
}

// ---------- Guided Filter (gray) ----------
function guidedFilterGray(I:Float32Array, p:Float32Array, w:number, h:number, r=4, eps=1e-3){
  function boxMean(src:Float32Array):Float32Array{
    const dst=new Float32Array(w*h);
    const integral=new Float32Array((w+1)*(h+1));
    for(let y=1;y<=h;y++){
      let rowsum=0;
      for(let x=1;x<=w;x++){
        rowsum += src[(y-1)*w+(x-1)];
        integral[y*(w+1)+x] = integral[(y-1)*(w+1)+x] + rowsum;
      }
    }
    for(let y=0;y<h;y++){
      const y0=Math.max(0,y-r), y1=Math.min(h-1,y+r);
      for(let x=0;x<w;x++){
        const x0=Math.max(0,x-r), x1=Math.min(w-1,x+r);
        const A=integral[y0*(w+1)+x0], B=integral[y0*(w+1)+(x1+1)];
        const C=integral[(y1+1)*(w+1)+x0], D=integral[(y1+1)*(w+1)+(x1+1)];
        const area=(x1-x0+1)*(y1-y0+1);
        dst[y*w+x]=(D - B - C + A)/area;
      }
    }
    return dst;
  }
  const meanI=boxMean(I), meanP=boxMean(p);
  const meanIp=boxMean(new Float32Array(w*h).map((_,i)=>I[i]*p[i]));
  const corrI=boxMean(new Float32Array(w*h).map((_,i)=>I[i]*I[i]));
  const varI=new Float32Array(w*h).map((_,i)=>corrI[i]-meanI[i]*meanI[i]);

  const a=new Float32Array(w*h), b=new Float32Array(w*h);
  for(let i=0;i<w*h;i++){
    const covIp=meanIp[i]-meanI[i]*meanP[i];
    const ai=covIp/(varI[i]+eps);
    a[i]=ai;
    b[i]=meanP[i]-ai*meanI[i];
  }
  const meanA=boxMean(a), meanB=boxMean(b);
  const q=new Float32Array(w*h);
  for(let i=0;i<w*h;i++){ q[i]=meanA[i]*I[i]+meanB[i]; }
  return q;
}

// ---------- circular stats & categories ----------
function circularStatsDeg(hues:number[]){ const toRad=(d:number)=>d*Math.PI/180; let x=0,y=0; for(const h of hues){ x+=Math.cos(toRad(h)); y+=Math.sin(toRad(h)); } const n=Math.max(1,hues.length);
  const R=Math.sqrt((x/n)**2+(y/n)**2); let mean=Math.atan2(y,x)*180/Math.PI; if(mean<0) mean+=360; return { mean,R,circVar:1-R };
}
function circDist(a:number,b:number){ const d=Math.abs(a-b)%360; return d>180? 360-d : d; }
const CATS = [
  { name:"Gelb", center:90, width:25 },
  { name:"Gelbgrün", center:75, width:20 },
  { name:"Grün", center:140, width:25 },
  { name:"Blaugrün", center:190, width:22 },
  { name:"Blau", center:240, width:22 },
  { name:"Blauviolett", center:280, width:20 },
  { name:"Violett", center:300, width:22 },
  { name:"Rotviolett", center:330, width:20 },
  { name:"Rot", center:0, width:22 },
  { name:"Rotorange", center:20, width:18 },
  { name:"Orange", center:40, width:18 },
];
function softCategory(hueMean:number){ const scores=CATS.map(c=>({name:c.name, score:Math.exp(-0.5*(circDist(hueMean,c.center)/c.width)**2)})).sort((a,b)=>b.score-a.score);
  const conf=scores[0].score-((scores[1]?.score)||0); return { primary:scores[0], secondary:scores[1], conf, borderline: conf<0.15 };
}
function hueBorderlineFromHist(hist:number[], smooth=3){ const bin=hist.length; const sm=new Array(bin).fill(0);
  for(let i=0;i<bin;i++){ let s=0; for(let k=-smooth;k<=smooth;k++) s+=hist[(i+k+bin)%bin]; sm[i]=s; }
  const peaks:number[]=[]; for(let i=0;i<bin;i++){ const p=sm[i],L=sm[(i-1+bin)%bin],R=sm[(i+1)%bin]; if(p>L && p>R) peaks.push(i); }
  peaks.sort((a,b)=>a-b); let sepDeg=0; for(let i=0;i<peaks.length;i++){ const a=peaks[i], b=peaks[(i+1)%peaks.length]; const d=Math.min((b-a+bin)%bin,(a-b+bin)%bin)*(360/bin); if(d>6 && d<40){ sepDeg=d; break; } }
  return { sepDeg, sm };
}

export async function POST(req: NextRequest){
  try{
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if(!file) return NextResponse.json({ error: "No file" }, { status: 400 });
    const options = JSON.parse((form.get("options") as string) || "{}");

    const arrayBuffer = await file.arrayBuffer();
    const input = sharp(Buffer.from(arrayBuffer));
    const meta = await input.metadata();

    const maxEdge:number = options.scale ?? 512;
    let width = meta.width || 0, height = meta.height || 0;
    if(width===0 || height===0) return NextResponse.json({ error: "Unable to decode image" }, { status: 400 });
    const ratio = width>height ? maxEdge/width : maxEdge/height;
    const w = Math.max(1, Math.round(width*ratio));
    const h = Math.max(1, Math.round(height*ratio));

    const rawRGB = await input.resize(w,h,{ fit:"inside" }).raw().toBuffer(); // 3 channels

    // options
    const maskWhite = options.maskWhite ?? true;
    const maskBlack = options.maskBlack ?? true;
    const maskLowSat = options.maskLowSat ?? true;
    const whiteThr = options.whiteThr ?? 220;
    const blackThr = options.blackThr ?? 25;
    const satThr = options.satThr ?? 8;
    const slicStep = options.slicStep ?? 16;
    const slicM = options.slicM ?? 10;
    const guidedR = options.guidedR ?? 4;
    const guidedEps = options.guidedEps ?? 1e-3;

    // initial mask
    const mask = new Uint8Array(w*h);
    for(let i=0;i<w*h;i++){
      const r=rawRGB[i*3], g=rawRGB[i*3+1], b=rawRGB[i*3+2];
      const L=luma([r,g,b]); const [hue,sat,val]=rgbToHsv(r,g,b);
      let keep=true;
      if(maskWhite && L>whiteThr && sat<30) keep=false;
      if(maskBlack && L<blackThr) keep=false;
      if(maskLowSat && sat<satThr) keep=false;
      mask[i]=keep?255:0;
    }

    // SLIC refinement + majority vote
    const slic = slicSuperpixels(w,h,new Uint8Array(rawRGB), slicStep, slicM);
    const counts = Array.from({length:slic.clusters.length},()=>[0,0]);
    for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ const pos=y*w+x; const li=slic.labels[pos]; if(mask[pos]) counts[li][0]++; else counts[li][1]++; } }
    const choose = counts.map(c=> c[0]>=c[1] ? 255 : 0);
    const superMask = new Uint8Array(w*h);
    for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ const pos=y*w+x; superMask[pos]=choose[slic.labels[pos]]; } }

    // Guided filter
    const I = new Float32Array(w*h);
    for(let i=0;i<w*h;i++){ I[i]=luma([rawRGB[i*3],rawRGB[i*3+1],rawRGB[i*3+2]])/255; }
    const p = new Float32Array(w*h);
    for(let i=0;i<w*h;i++){ p[i]=superMask[i]/255; }
    const q = guidedFilterGray(I,p,w,h,guidedR,guidedEps);
    const finalMask = new Uint8Array(w*h);
    for(let i=0;i<w*h;i++){ finalMask[i]= q[i]>0.5 ? 255 : 0; }

    // Preview RGBA (kept=opaque; masked=alpha 90/255)
    const rgba = Buffer.alloc(w*h*4);
    let used=0, maskedPix=0;
    for(let i=0;i<w*h;i++){
      const r=rawRGB[i*3], g=rawRGB[i*3+1], b=rawRGB[i*3+2];
      rgba[i*4]=r; rgba[i*4+1]=g; rgba[i*4+2]=b;
      if(finalMask[i]===255){ rgba[i*4+3]=255; used++; }
      else { rgba[i*4+3]=90; maskedPix++; }
    }
    const previewPng = await sharp(rgba, { raw: { width:w, height:h, channels:4 }}).png().toBuffer();
    const previewDataUrl = "data:image/png;base64," + previewPng.toString("base64");

    // collect kept points
    const usedPoints:number[][]=[];
    for(let i=0;i<w*h;i++){
      if(finalMask[i]===255){
        usedPoints.push([rawRGB[i*3],rawRGB[i*3+1],rawRGB[i*3+2]]);
      }
    }

    // algo override
    const algo:string = options.algo ?? "auto"; // "auto" | "kmeans" | "gmm"
    const K = options.k ?? 5;

    let clusters: Cluster[] = [];
    let chosenK = K;

    if(algo==="kmeans"){
      clusters = kmeansRGB(usedPoints, K, 25);
      chosenK = K;
    } else if(algo==="gmm"){
      const best = gmmDiagBIC(usedPoints, K, K, 25);
      chosenK = best.k;
      clusters = kmeansRGB(usedPoints, chosenK, 25);
    } else {
      const best = gmmDiagBIC(usedPoints, 3, 8, 20);
      chosenK = best.k;
      clusters = kmeansRGB(usedPoints, chosenK, 25);
    }

    // stats & borderline
    const hues:number[]=[], sats:number[]=[], vals:number[]=[], Ls:number[]=[], As:number[]=[], Bs:number[]=[], hueHist=new Array(360).fill(0);
    const white:[number,number,number] = options.useD50 ? [0.96422,1.0,0.82521] : [0.95047,1.0,1.08883];
    for(const pnt of usedPoints){
      const [hue,sat,val]=rgbToHsv(pnt[0],pnt[1],pnt[2]); hues.push(hue); sats.push(sat); vals.push(val); hueHist[Math.floor(hue)%360]++;
      const lab=rgbToLab(pnt[0],pnt[1],pnt[2], white); Ls.push(lab.L); As.push(lab.a); Bs.push(lab.b);
    }
    const mean=(arr:number[])=>arr.reduce((a,b)=>a+b,0)/Math.max(1,arr.length);
    const sorted=(arr:number[])=>arr.slice().sort((a,b)=>a-b);
    const med=(arr:number[])=>{ const s=sorted(arr); const m=Math.floor(s.length/2); return s.length%2?s[m]:(s[m-1]+s[m])/2; };

    const circ=circularStatsDeg(hues); const hb=hueBorderlineFromHist(hueHist,3); const cat=softCategory(circ.mean);
    const abSamples:[number,number][]=[]; const step=Math.max(1,Math.floor(As.length/2000)); for(let i=0;i<As.length;i+=step){ abSamples.push([As[i],Bs[i]]); }

    const refHex = options.refHex ?? "#007C7A";
    const refRgb = [parseInt(refHex.slice(1,3),16), parseInt(refHex.slice(3,5),16), parseInt(refHex.slice(5,7),16)] as [number,number,number];
    const refLab = rgbToLab(refRgb[0],refRgb[1],refRgb[2], white);
    const meanLab:Lab = { L: mean(Ls), a: mean(As), b: mean(Bs) };
    const dE76 = deltaE76(meanLab, refLab);
    const dE2000v = deltaE2000(meanLab, refLab);

    const result = {
      width:w,height:h,totalPixels:w*h,usedPixels:used,maskRatio:maskedPix/(w*h),
      k: chosenK, clusters,
      hsvStats:{ hueMean:mean(hues), satMean:mean(sats), valMean:mean(vals), hueMedian:med(hues), satMedian:med(sats), valMedian:med(vals) },
      labStats:{ Lmean:mean(Ls), aMean:mean(As), bMean:mean(Bs), Lmedian:med(Ls), aMedian:med(As), bMedian:med(Bs) },
      refDeltaE:{ hex: refHex, dE76, dE2000: dE2000v },
      hue:{ mean:circ.mean, R:circ.R, circVar:circ.circVar, sepDeg:hb.sepDeg, category:{ primary:cat.primary, secondary:cat.secondary, conf:cat.conf, borderline:cat.borderline } },
      hueHist, abSamples,
      previewDataUrl,
      params:{ algo, k:K, slicStep, slicM, guidedR, guidedEps, white }
    };
    return NextResponse.json(result);
  }catch(err:any){
    return NextResponse.json({ error: err?.message || String(err) }, { status: 500 });
  }
}