import { NextRequest, NextResponse } from "next/server";
import JSZip from "jszip";
import sharp from "sharp";
import { POST as analyzeSingle } from "../route"; // reuse by calling the same logic? Not trivial due to Next.js handler signature.
// For simplicity, we inline a minimal wrapper to re-run the analysis function here by importing logic would be complex in a single file.
// In a real project, factor out shared analyzer into a module. For this export, we do a lightweight re-implementation by calling the analyze API per file via fetch is not possible on server.
// To keep this example concise, we parse each file and call the same logic as /api/analyze by sending a subrequest-like flow.

export async function POST(req: NextRequest){
  try{
    const form = await req.formData();
    const files = form.getAll("files") as File[];
    const options = JSON.parse((form.get("options") as string) || "{}");
    if(!files.length) return NextResponse.json({ error: "No files" }, { status: 400 });

    // We'll call the local analyze route handler for each file by constructing a synthetic NextRequest per file.
    const zip = new JSZip();
    const summaryLines:string[] = [];
    summaryLines.push("file,k,hueMean,satMean,valMean,L*,a*,b*,dE76,dE2000,top1,share1,top2,share2,top3,share3");

    for(const f of files){
      const fd = new FormData();
      fd.append("file", f);
      fd.append("options", JSON.stringify(options));
      // create synthetic request
      const singleReq = new Request("http://local/api/analyze", { method:"POST", body: fd as any });
      // @ts-ignore
      const res = await (analyzeSingle as any)(singleReq);
      const json = await res.json();
      const name = (f as any).name || "image";
      zip.file(`${name.replace(/\.[^.]+$/, "")}.json`, JSON.stringify(json, null, 2));
      if(json.previewDataUrl){
        const b64 = json.previewDataUrl.split(",")[1];
        zip.file(`previews/${name.replace(/\.[^.]+$/, "")}.png`, Buffer.from(b64, "base64"));
      }
      const c = json.clusters || [];
      const c1=c[0]||{}, c2=c[1]||{}, c3=c[2]||{};
      summaryLines.push([
        name, json.k, json.hsvStats?.hueMean?.toFixed?.(2), json.hsvStats?.satMean?.toFixed?.(2), json.hsvStats?.valMean?.toFixed?.(2),
        json.labStats?.Lmean?.toFixed?.(2), json.labStats?.aMean?.toFixed?.(2), json.labStats?.bMean?.toFixed?.(2),
        json.refDeltaE?.dE76?.toFixed?.(2), json.refDeltaE?.dE2000?.toFixed?.(2),
        c1.hex||"", ((c1.share||0)*100).toFixed(1)+"%",
        c2.hex||"", ((c2.share||0)*100).toFixed(1)+"%",
        c3.hex||"", ((c3.share||0)*100).toFixed(1)+"%"
      ].join(","));
    }

    zip.file("summary.csv", summaryLines.join("\n"));
    const buf = await zip.generateAsync({ type:"nodebuffer" });
    return new NextResponse(buf, { status:200, headers: { "Content-Type":"application/zip", "Content-Disposition":"attachment; filename=batch-analysis.zip" } });
  }catch(err:any){
    return NextResponse.json({ error: err?.message || String(err) }, { status: 500 });
  }
}