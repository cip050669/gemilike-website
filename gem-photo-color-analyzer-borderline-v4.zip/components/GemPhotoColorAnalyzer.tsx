"use client";
import React, { useCallback, useMemo, useRef, useState } from "react";

type Cluster = { hex:string; rgb:[number,number,number]; hsv:[number,number,number]; share:number };
type Lab = { L:number; a:number; b:number };

// ---------- utils ----------
const clamp=(n:number,a:number,b:number)=>Math.max(a,Math.min(b,n));
const toHex=([r,g,b]:[number,number,number])=>`#${[r,g,b].map(v=>v.toString(16).padStart(2,"0")).join("")}`;
function hexToRgb(hex:string):[number,number,number]{ const h=hex.replace("#",""); const v=h.length===3?h.split("").map(c=>c+c).join(""):h; const n=parseInt(v,16); return [(n>>16)&255,(n>>8)&255,n&255]; }
function rgbToHsv(r:number,g:number,b:number):[number,number,number]{ r/=255; g/=255; b/=255; const max=Math.max(r,g,b), min=Math.min(r,g,b); const d=max-min;
  let h=0; if(d===0)h=0; else if(max===r)h=60*(((g-b)/d)%6); else if(max===g)h=60*(((b-r)/d)+2); else h=60*(((r-g)/d)+4); if(h<0)h+=360;
  const s=max===0?0:(d/max); const v=max; return [h,s*100,v*100];
}
function luma([r,g,b]:[number,number,number]){ return 0.2126*r+0.7152*g+0.0722*b; }

function srgbToLinear(c:number){ c/=255; return c<=0.04045? c/12.92 : Math.pow((c+0.055)/1.055,2.4); }
function rgbToXyz(r:number,g:number,b:number){ const R=srgbToLinear(r),G=srgbToLinear(g),B=srgbToLinear(b);
  const x=R*0.4124564+G*0.3575761+B*0.1804375; const y=R*0.2126729+G*0.7151522+B*0.0721750; const z=R*0.0193339+G*0.1191920+B*0.9503041; return [x,y,z];
}
function xyzToLab(x:number,y:number,z:number, wp:[number,number,number]=[0.95047,1.0,1.08883]){ // D65 default
  const [Xr,Yr,Zr]=wp; const fx=(t:number)=>t>Math.pow(6/29,3)?Math.cbrt(t):(t/(3*Math.pow(6/29,2))+4/29);
  const L=116*fx(y/Yr)-16; const a=500*(fx(x/Xr)-fx(y/Yr)); const b=200*(fx(y/Yr)-fx(z/Zr)); return {L,a,b};
}
function rgbToLab(r:number,g:number,b:number, wp:[number,number,number]=[0.95047,1.0,1.08883]):Lab{ const [x,y,z]=rgbToXyz(r,g,b); return xyzToLab(x,y,z, wp); }
function deltaE76(l1:Lab,l2:Lab){ const dL=l1.L-l2.L, da=l1.a-l2.a, db=l1.b-l2.b; return Math.sqrt(dL*dL+da*da+db*db); }
function deltaE2000(l1:Lab,l2:Lab){
  const {L:L1,a:a1,b:b1}=l1,{L:L2,a:a2,b:b2}=l2; const kL=1,kC=1,kH=1; const C1=Math.hypot(a1,b1),C2=Math.hypot(a2,b2);
  const Cbar=(C1+C2)/2; const G=0.5*(1-Math.sqrt(Math.pow(Cbar,7)/(Math.pow(Cbar,7)+Math.pow(25,7))));
  const a1p=(1+G)*a1,a2p=(1+G)*a2; const C1p=Math.hypot(a1p,b1),C2p=Math.hypot(a2p,b2);
  const h1p=(Math.atan2(b1,a1p)*180/Math.PI+360)%360, h2p=(Math.atan2(b2,a2p)*180/Math.PI+360)%360;
  const dLp=L2-L1,dCp=C2p-C1p; let dhp=0; if(C1p*C2p!==0){ const dh=h2p-h1p; dhp=Math.abs(dh)<=180?dh:(dh>180?dh-360:dh+360); }
  const dHp=2*Math.sqrt(C1p*C2p)*Math.sin((dhp*Math.PI/180)/2);
  const Lbar=(L1+L2)/2,Cbarp=(C1p+C2p)/2; let hbarp=0; if(C1p*C2p===0) hbarp=h1p+h2p; else { const dh=Math.abs(h1p-h2p); hbarp=(dh<=180?(h1p+h2p)/2:(h1p+h2p+360)/2); if(hbarp>=360) hbarp-=360; }
  const T=1-0.17*Math.cos((hbarp-30)*Math.PI/180)+0.24*Math.cos((2*hbarp)*Math.PI/180)+0.32*Math.cos((3*hbarp+6)*Math.PI/180)-0.20*Math.cos((4*hbarp-63)*Math.PI/180);
  const dRo=30*Math.exp(-((hbarp-275)/25)**2); const Rc=2*Math.sqrt(Math.pow(Cbarp,7)/(Math.pow(Cbarp,7)+Math.pow(25,7)));
  const Sl=1+((0.015*(Lbar-50)**2)/Math.sqrt(20+(Lbar-50)**2)); const Sc=1+0.045*Cbarp; const Sh=1+0.015*Cbarp*T; const Rt=-Math.sin(2*(dRo*Math.PI/180))*Rc;
  return Math.sqrt(Math.pow(dLp/(kL*Sl),2)+Math.pow(dCp/(kC*Sc),2)+Math.pow(dHp/(kH*Sh),2)+Rt*(dLp/(kL*Sl))*(dCp/(kC*Sc)));
}

// Bradford adaptation D65<->D50
function bradfordAdaptXYZ(X:number,Y:number,Z:number, toD50:boolean){
  const M = [
    [ 0.8951,  0.2664, -0.1614],
    [-0.7502,  1.7135,  0.0367],
    [ 0.0389, -0.0685,  1.0296],
  ];
  const Minv = [
    [ 0.9869929, -0.1470543, 0.1599627],
    [ 0.4323053,  0.5183603, 0.0492912],
    [-0.0085287,  0.0400428, 0.9684867],
  ];
  const D65=[0.95047,1.00000,1.08883], D50=[0.96422,1.00000,0.82521];
  const src = toD50? D65:D50, dst=toD50? D50:D65;
  const cone = [M[0][0]*X+M[0][1]*Y+M[0][2]*Z, M[1][0]*X+M[1][1]*Y+M[1][2]*Z, M[2][0]*X+M[2][1]*Y+M[2][2]*Z];
  const scale=[dst[0]/src[0], dst[1]/src[1], dst[2]/src[2]];
  const cone2=[cone[0]*scale[0], cone[1]*scale[1], cone[2]*scale[2]];
  const X2 = Minv[0][0]*cone2[0]+Minv[0][1]*cone2[1]+Minv[0][2]*cone2[2];
  const Y2 = Minv[1][0]*cone2[0]+Minv[1][1]*cone2[1]+Minv[1][2]*cone2[2];
  const Z2 = Minv[2][0]*cone2[0]+Minv[2][1]*cone2[1]+Minv[2][2]*cone2[2];
  return [X2,Y2,Z2] as [number,number,number];
}

// ---------- K-Means++ ----------
function kmeansPlusPlusInit(points:number[][], k:number){
  const n=points.length, centroids:number[][]=[];
  centroids.push(points[Math.floor(Math.random()*n)]);
  const dist2 = (p:number[], c:number[])=> (p[0]-c[0])**2+(p[1]-c[1])**2+(p[2]-c[2])**2;
  while(centroids.length<k){
    const ds = points.map(p=> Math.min(...centroids.map(c=>dist2(p,c))));
    const sum = ds.reduce((a,b)=>a+b,0); let r=Math.random()*sum, idx=0;
    for(let i=0;i<n;i++){ r -= ds[i]; if(r<=0){ idx=i; break; } }
    centroids.push(points[idx]);
  }
  return centroids;
}
function kmeansRGB(points:Uint8ClampedArray,k:number,maxIter=25, usePP=true):Cluster[]{
  const n=Math.floor(points.length/4);
  const pts=new Array<[number,number,number]>(n);
  for(let i=0;i<n;i++) pts[i]=[points[i*4],points[i*4+1],points[i*4+2]];
  let centroids:[number,number,number][];
  if(usePP){ const inits=kmeansPlusPlusInit(pts as any, k); centroids=inits.map(c=>[c[0],c[1],c[2]] as [number,number,number]); }
  else { centroids=[pts[Math.floor(n/3)] as [number,number,number]]; while(centroids.length<k){ centroids.push(pts[Math.floor(Math.random()*n)] as [number,number,number]); } }
  const labels=new Uint16Array(n);
  for(let it=0;it<maxIter;it++){
    let moved=false;
    for(let i=0;i<n;i++){ const p=pts[i]; let bi=0, bd=Infinity; for(let c=0;c<k;c++){ const cc=centroids[c]; const d=(p[0]-cc[0])**2+(p[1]-cc[1])**2+(p[2]-cc[2])**2; if(d<bd){ bd=d; bi=c; } } if(labels[i]!==bi){ labels[i]=bi; moved=true; } }
    const sum=Array.from({length:k},()=>[0,0,0,0]);
    for(let i=0;i<n;i++){ const li=labels[i], p=pts[i]; sum[li][0]+=p[0]; sum[li][1]+=p[1]; sum[li][2]+=p[2]; sum[li][3]++; }
    for(let c=0;c<k;c++){ const cnt=sum[c][3]||1; centroids[c]=[Math.round(sum[c][0]/cnt),Math.round(sum[c][1]/cnt),Math.round(sum[c][2]/cnt)]; }
    if(!moved) break;
  }
  const counts=new Array(k).fill(0); for(let i=0;i<n;i++) counts[labels[i]]++;
  return centroids.map((c,i)=>{ const hsv=rgbToHsv(c[0],c[1],c[2]); return {rgb:c as [number,number,number],hex:toHex(c as any),hsv,share:counts[i]/n}; }).sort((a,b)=>b.share-a.share);
}

// ---------- GMM (diagonal) + BIC for auto-K ----------
function gmmDiagBIC(points:number[][], Kmin=3, Kmax=8, iters=30){
  const X=points, n=X.length, d=3;
  function randn(){ // Box-Muller
    let u=0,v=0; while(u===0)u=Math.random(); while(v===0)v=Math.random(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
  }
  function initKMeansPP(k:number){
    const C=kmeansPlusPlusInit(X,k); // reuse
    return C;
  }
  function em(k:number){
    // init means
    let means=initKMeansPP(k).map(c=>c.slice());
    let weights=Array(k).fill(1/k);
    let vars=Array.from({length:k},()=>Array(d).fill(4000)); // large start variances
    const resp=Array.from({length:n},()=>Array(k).fill(0));
    for(let it=0;it<iters;it++){
      // E-step
      for(let i=0;i<n;i++){
        let sumr=0;
        for(let j=0;j<k;j++){
          let p=1;
          for(let t=0;t<d;t++){
            const diff=X[i][t]-means[j][t];
            const v=vars[j][t];
            p*=Math.exp(-0.5*diff*diff/v)/Math.sqrt(2*Math.PI*v);
          }
          resp[i][j]=weights[j]*p;
          sumr+=resp[i][j];
        }
        if(sumr===0){ for(let j=0;j<k;j++) resp[i][j]=1/k; }
        else { for(let j=0;j<k;j++) resp[i][j]/=sumr; }
      }
      // M-step
      for(let j=0;j<k;j++){
        let Nj=0; const mu=[0,0,0];
        for(let i=0;i<n;i++){ Nj+=resp[i][j]; mu[0]+=resp[i][j]*X[i][0]; mu[1]+=resp[i][j]*X[i][1]; mu[2]+=resp[i][j]*X[i][2]; }
        mu[0]/=Nj; mu[1]/=Nj; mu[2]/=Nj;
        means[j]=mu.slice();
        const v=[0,0,0];
        for(let i=0;i<n;i++){ v[0]+=resp[i][j]*(X[i][0]-mu[0])**2; v[1]+=resp[i][j]*(X[i][1]-mu[1])**2; v[2]+=resp[i][j]*(X[i][2]-mu[2])**2; }
        v[0]/=Nj; v[1]/=Nj; v[2]/=Nj;
        vars[j]=v.map(x=>Math.max(50, x)); // floor variance
        weights[j]=Nj/n;
      }
    }
    // log-likelihood
    let ll=0;
    for(let i=0;i<n;i++){
      let s=0;
      for(let j=0;j<k;j++){
        let p=1;
        for(let t=0;t<d;t++){
          const diff=X[i][t]-means[j][t], v=vars[j][t];
          p*=Math.exp(-0.5*diff*diff/v)/Math.sqrt(2*Math.PI*v);
        }
        s+=weights[j]*p;
      }
      ll+=Math.log(Math.max(1e-12,s));
    }
    // parameters count: k*(d means + d vars) + (k-1) weights
    const params = k*(d+d) + (k-1);
    const bic = -2*ll + params*Math.log(n);
    return { means, vars, weights, bic, ll, k };
  }

  let best:any=null;
  for(let k=Kmin;k<=Kmax;k++){
    const run=em(k);
    if(!best || run.bic<best.bic) best=run;
  }
  return best;
}

// ---------- Circular hue & soft categories ----------
function circularStatsDeg(hues:number[]){ const toRad=(d:number)=>d*Math.PI/180; let x=0,y=0; for(const h of hues){ x+=Math.cos(toRad(h)); y+=Math.sin(toRad(h)); } const n=Math.max(1,hues.length);
  const R=Math.sqrt((x/n)**2+(y/n)**2); let mean=Math.atan2(y,x)*180/Math.PI; if(mean<0) mean+=360; return { mean,R,circVar:1-R };
}
function circDist(a:number,b:number){ const d=Math.abs(a-b)%360; return d>180? 360-d : d; }
const CATS = [
  { name:"Gelb", center:90, width:25 },
  { name:"Gelbgrün", center:75, width:20 },
  { name:"Grün", center:140, width:25 },
  { name:"Blaugrün", center:190, width:22 },
  { name:"Blau", center:240, width:22 },
  { name:"Blauviolett", center:280, width:20 },
  { name:"Violett", center:300, width:22 },
  { name:"Rotviolett", center:330, width:20 },
  { name:"Rot", center:0, width:22 },
  { name:"Rotorange", center:20, width:18 },
  { name:"Orange", center:40, width:18 },
];
function softCategory(hueMean:number){ const scores=CATS.map(c=>({name:c.name, score:Math.exp(-0.5*(circDist(hueMean,c.center)/c.width)**2)})).sort((a,b)=>b.score-a.score);
  const conf=scores[0].score-((scores[1]?.score)||0); return { primary:scores[0], secondary:scores[1], conf, borderline: conf<0.15, scores };
}
function hueBorderlineFromHist(hist:number[], smooth=3){ const bin=hist.length; const sm=new Array(bin).fill(0);
  for(let i=0;i<bin;i++){ let s=0; for(let k=-smooth;k<=smooth;k++) s+=hist[(i+k+bin)%bin]; sm[i]=s; }
  const peaks:number[]=[]; for(let i=0;i<bin;i++){ const p=sm[i],L=sm[(i-1+bin)%bin],R=sm[(i+1)%bin]; if(p>L && p>R) peaks.push(i); }
  peaks.sort((a,b)=>a-b); let sepDeg=0; for(let i=0;i<peaks.length;i++){ const a=peaks[i], b=peaks[(i+1)%peaks.length]; const d=Math.min((b-a+bin)%bin,(a-b+bin)%bin)*(360/bin); if(d>6 && d<40){ sepDeg=d; break; } }
  return { sepDeg, sm };
}

// ---------- SLIC Superpixels (simplified) ----------
function slicSuperpixels(img:ImageData, step=16, m=10){
  const {width:w,height:h,data} = img;
  const S=step;
  const clusters:number[][]=[];
  const labels = new Int32Array(w*h).fill(-1);
  const dists = new Float32Array(w*h).fill(Infinity);

  function colorAt(i:number){ return [data[i],data[i+1],data[i+2]] as [number,number,number]; }
  function l2(a:number[],b:number[]){ return Math.hypot(a[0]-b[0], a[1]-b[1], a[2]-b[2]); }

  // init grid
  for(let y=S/2; y<h; y+=S){
    for(let x=S/2; x<w; x+=S){
      const i=(Math.floor(y)*w+Math.floor(x))*4;
      const rgb=colorAt(i);
      clusters.push([x,y,rgb[0],rgb[1],rgb[2]]); // x,y,r,g,b
    }
  }
  const nc=clusters.length;
  const iter=5;
  for(let it=0; it<iter; it++){
    // assignment
    for(let ci=0; ci<nc; ci++){
      const cx=clusters[ci][0], cy=clusters[ci][1];
      for(let y=Math.max(0,Math.floor(cy-S)); y<Math.min(h,Math.floor(cy+S)); y++){
        for(let x=Math.max(0,Math.floor(cx-S)); x<Math.min(w,Math.floor(cx+S)); x++){
          const i=(y*w+x)*4;
          const dc=l2(colorAt(i),[clusters[ci][2],clusters[ci][3],clusters[ci][4]]);
          const ds=Math.hypot(x-cx,y-cy);
          const D=Math.sqrt(dc*dc + (ds/S)*(ds/S)*m*m);
          if(D<dists[y*w+x]){ dists[y*w+x]=D; labels[y*w+x]=ci; }
        }
      }
    }
    // update
    const acc = Array.from({length:nc},()=>[0,0,0,0,0,0]); // x,y,r,g,b,count
    for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ const li=labels[y*w+x]; if(li<0) continue; const i=(y*w+x)*4; acc[li][0]+=x; acc[li][1]+=y; acc[li][2]+=data[i]; acc[li][3]+=data[i+1]; acc[li][4]+=data[i+2]; acc[li][5]+=1; } }
    for(let ci=0; ci<nc; ci++){ const c=acc[ci]; const N=Math.max(1,c[5]); clusters[ci]=[c[0]/N,c[1]/N,c[2]/N,c[3]/N,c[4]/N]; }
    dists.fill(Infinity);
  }
  return { labels, clusters, step:S, width:w, height:h };
}

// ---------- Guided Filter (on alpha/mask) ----------
function guidedFilterGray(I:Float32Array, p:Float32Array, w:number, h:number, r=4, eps=1e-3){
  // mean via box filter
  function boxMean(src:Float32Array):Float32Array{
    const dst=new Float32Array(w*h);
    // integral image
    const integral=new Float32Array((w+1)*(h+1));
    for(let y=1;y<=h;y++){
      let rowsum=0;
      for(let x=1;x<=w;x++){
        rowsum += src[(y-1)*w+(x-1)];
        integral[y*(w+1)+x] = integral[(y-1)*(w+1)+x] + rowsum;
      }
    }
    const rad=r;
    for(let y=0;y<h;y++){
      const y0=Math.max(0,y-rad), y1=Math.min(h-1,y+rad);
      for(let x=0;x<w;x++){
        const x0=Math.max(0,x-rad), x1=Math.min(w-1,x+rad);
        const A=integral[y0*(w+1)+x0], B=integral[y0*(w+1)+(x1+1)];
        const C=integral[(y1+1)*(w+1)+x0], D=integral[(y1+1)*(w+1)+(x1+1)];
        const area=(x1-x0+1)*(y1-y0+1);
        dst[y*w+x]=(D - B - C + A)/area;
      }
    }
    return dst;
  }
  const meanI=boxMean(I), meanP=boxMean(p);
  const meanIp=boxMean(new Float32Array(w*h).map((_,i)=>I[i]*p[i]));
  const corrI=boxMean(new Float32Array(w*h).map((_,i)=>I[i]*I[i]));
  const varI=new Float32Array(w*h).map((_,i)=>corrI[i]-meanI[i]*meanI[i]);

  const a=new Float32Array(w*h), b=new Float32Array(w*h);
  for(let i=0;i<w*h;i++){
    const covIp=meanIp[i]-meanI[i]*meanP[i];
    const ai=covIp/(varI[i]+eps);
    a[i]=ai;
    b[i]=meanP[i]-ai*meanI[i];
  }
  const meanA=boxMean(a), meanB=boxMean(b);
  const q=new Float32Array(w*h);
  for(let i=0;i<w*h;i++){ q[i]=meanA[i]*I[i]+meanB[i]; }
  return q;
}

// ---------- ICC parser (minimal: wtpt, rXYZ,gXYZ,bXYZ) ----------
function parseICC(buf:Uint8Array){
  function read32be(o:number){ return (buf[o]<<24)|(buf[o+1]<<16)|(buf[o+2]<<8)|buf[o+3]; }
  function s15Fixed16(n:number){ return (n>>16) + ( (n & 0xFFFF) / 65536 ); }
  const tagCount = read32be(128+4);
  const tags:any={};
  for(let i=0;i<tagCount;i++){
    const base = 128+8 + i*12;
    const sig = String.fromCharCode(buf[base],buf[base+1],buf[base+2],buf[base+3]);
    const off = read32be(base+4);
    const size= read32be(base+8);
    const typeSig = String.fromCharCode(buf[off],buf[off+1],buf[off+2],buf[off+3]);
    if(typeSig==="XYZ "){
      const count=(size-8)/12;
      const vals:number[]=[];
      for(let j=0;j<count;j++){
        const X=s15Fixed16(read32be(off+8+j*12));
        const Y=s15Fixed16(read32be(off+8+j*12+4));
        const Z=s15Fixed16(read32be(off+8+j*12+8));
        vals.push(X,Y,Z);
      }
      tags[sig]=vals;
    }
  }
  const wtpt = tags["wtpt"] ? [tags["wtpt"][0], tags["wtpt"][1], tags["wtpt"][2]] : null;
  const rXYZ = tags["rXYZ"] ? [tags["rXYZ"][0], tags["rXYZ"][1], tags["rXYZ"][2]] : null;
  const gXYZ = tags["gXYZ"] ? [tags["gXYZ"][0], tags["gXYZ"][1], tags["gXYZ"][2]] : null;
  const bXYZ = tags["bXYZ"] ? [tags["bXYZ"][0], tags["bXYZ"][1], tags["bXYZ"][2]] : null;
  return { wtpt, rXYZ, gXYZ, bXYZ };
}

// ---------- component ----------
export default function GemPhotoColorAnalyzer(){
  const [file, setFile] = useState<File|undefined>();
  const [url, setUrl] = useState<string|undefined>();
  const [k, setK] = useState(5);
  const [autoK, setAutoK] = useState(true);
  const [scale, setScale] = useState(512);
  const [maskWhite, setMaskWhite] = useState(true);
  const [maskBlack, setMaskBlack] = useState(true);
  const [maskLowSat, setMaskLowSat] = useState(true);
  const [smartMask, setSmartMask] = useState(true);
  const [whiteThr, setWhiteThr] = useState(220);
  const [blackThr, setBlackThr] = useState(25);
  const [satThr, setSatThr] = useState(8);
  const [analysis, setAnalysis] = useState<any|undefined>();
  const [serverPreview, setServerPreview] = useState<string|undefined>();

  const [useServer, setUseServer] = useState(false);
  const [algo, setAlgo] = useState<"auto"|"kmeans"|"gmm">("auto");

  const [refHex, setRefHex] = useState("#007C7A");
  const [useD50, setUseD50] = useState(false);
  const [iccInfo, setIccInfo] = useState<any|undefined>();
  const [iccWP, setIccWP] = useState<[number,number,number]|undefined>();
  const [slicStep, setSlicStep] = useState(16);
  const [slicM, setSlicM] = useState(10);
  const [guidedR, setGuidedR] = useState(4);
  const [guidedEps, setGuidedEps] = useState(1e-3);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const origRef = useRef<HTMLImageElement>(null);

  const onPick = useCallback((f:File)=>{ setFile(f); setUrl(URL.createObjectURL(f)); setAnalysis(undefined); },[]);
  const onInput = useCallback((e:React.ChangeEvent<HTMLInputElement>)=>{ const f=e.target.files?.[0]; if(f) onPick(f); },[onPick]);
  const prevent = (e:React.DragEvent)=>{ e.preventDefault(); };
  const onDrop = (e:React.DragEvent)=>{ e.preventDefault(); const f=e.dataTransfer.files?.[0]; if(f) onPick(f); };

  const onICC = useCallback(async (e:React.ChangeEvent<HTMLInputElement>)=>{
    const f=e.target.files?.[0]; if(!f) return;
    const buf = new Uint8Array(await f.arrayBuffer());
    const parsed = parseICC(buf);
    setIccInfo(parsed);
    if(parsed.wtpt){ setIccWP([parsed.wtpt[0], parsed.wtpt[1], parsed.wtpt[2]] as [number,number,number]); }
  },[]);

  const run = useCallback(async ()=>{
    if(useServer){
      if(!url || !file) return;
      const fd = new FormData();
      fd.append("file", file);
      fd.append("options", JSON.stringify({
        scale, maskWhite, maskBlack, maskLowSat, whiteThr, blackThr, satThr,
        refHex, useD50, algo, k
      }));
      const res = await fetch("/api/analyze", { method:"POST", body: fd });
      const json = await res.json();
      if(!res.ok){ alert(json.error || "Server-Analyse fehlgeschlagen"); return; }
      setAnalysis(json); setServerPreview(json.previewDataUrl);
      // also draw a quick preview rectangle as placeholder (no server image return)
      if(canvasRef.current){
        const c=canvasRef.current; c.width=json.width; c.height=json.height;
        const ctx=c.getContext("2d")!; ctx.fillStyle="#fff"; ctx.fillRect(0,0,c.width,c.height);
        ctx.fillStyle="#000"; ctx.fillText("Server-Analyse: Vorschau nicht übertragen", 10, 20);
      }
      return;
    }

    if(!url) return;
    const img = await new Promise<HTMLImageElement>((res,rej)=>{ const im=new Image(); im.onload=()=>res(im); im.onerror=rej; im.src=url; });
    const w0=img.width,h0=img.height; const ratio=w0>h0? scale/w0 : scale/h0; const w=Math.max(1,Math.round(w0*ratio)), h=Math.max(1,Math.round(h0*ratio));
    const cvs=document.createElement("canvas"); cvs.width=w; cvs.height=h; const ctx=cvs.getContext("2d",{willReadFrequently:true})!; ctx.drawImage(img,0,0,w,h);
    const imgd=ctx.getImageData(0,0,w,h); const data=imgd.data;

    const borders:[number,number,number][]=[];
    if(smartMask){
      const step=Math.max(1,Math.floor(Math.min(w,h)/64));
      for(let x=0;x<w;x+=step){ const i=(0*w+x)*4; borders.push([data[i],data[i+1],data[i+2]]); const j=((h-1)*w+x)*4; borders.push([data[j],data[j+1],data[j+2]]); }
      for(let y=0;y<h;y+=step){ const i=(y*w+0)*4; borders.push([data[i],data[i+1],data[i+2]]); const j=(y*w+(w-1))*4; borders.push([data[j],data[j+1],data[j+2]]); }
    }
    const bgLike=(r:number,g:number,b:number)=>{
      const [h,s,v]=rgbToHsv(r,g,b); const L=luma([r,g,b]);
      for(const [br,bg,bb] of borders){
        const [bh,bs,bv]=rgbToHsv(br,bg,bb); const dH=Math.min(Math.abs(h-bh),360-Math.abs(h-bh));
        const dS=Math.abs(s-bs), dV=Math.abs(v-bv); const dL=Math.abs(L-luma([br,bg,bb]));
        if(dH<18 && dS<28 && dV<28) return true; if(dL<22 && s<10) return true;
      } return false;
    };

    // initial mask
    const mask=new Uint8ClampedArray(w*h).fill(0);
    for(let i=0;i<w*h;i++){
      const r=data[i*4], g=data[i*4+1], b=data[i*4+2];
      const L=luma([r,g,b]); const [hue,sat,val]=rgbToHsv(r,g,b);
      let keep=true;
      if(maskWhite && L>whiteThr && sat<30) keep=false;
      if(maskBlack && L<blackThr) keep=false;
      if(maskLowSat && sat<satThr) keep=false;
      if(smartMask && bgLike(r,g,b)) keep=false;
      mask[i]=keep?255:0;
    }

    // --- SLIC refinement + majority voting
    const slic = slicSuperpixels(imgd, slicStep, slicM);
    // majority per superpixel
    const superMask = new Uint8ClampedArray(w*h);
    const counts = Array.from({length:slic.clusters.length},()=>[0,0]); // [fg,bg]
    for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ const li=slic.labels[y*w+x]; if(mask[y*w+x]) counts[li][0]++; else counts[li][1]++; } }
    const choose = counts.map(c=> c[0]>=c[1] ? 255 : 0);
    for(let y=0;y<h;y++){ for(let x=0;x<w;x++){ superMask[y*w+x]=choose[slic.labels[y*w+x]]; } }

    // --- Guided filter to smooth edges (use intensity as guide)
    const I = new Float32Array(w*h);
    for(let i=0;i<w*h;i++){ I[i]=luma([data[i*4],data[i*4+1],data[i*4+2]])/255; }
    const p = new Float32Array(w*h);
    for(let i=0;i<w*h;i++){ p[i]=superMask[i]/255; }
    const q = guidedFilterGray(I,p,w,h,guidedR,guidedEps);
    // binarize
    const finalMask = new Uint8ClampedArray(w*h);
    for(let i=0;i<w*h;i++){ finalMask[i]= q[i]>0.5 ? 255 : 0; }

    // preview build
    const out=new Uint8ClampedArray(w*h*4); let used=0, maskedPix=0;
    for(let i=0;i<w*h;i++){
      const r=data[i*4], g=data[i*4+1], b=data[i*4+2], a=data[i*4+3];
      if(finalMask[i]===255 && a>5){ out[i*4]=r; out[i*4+1]=g; out[i*4+2]=b; out[i*4+3]=255; used++; }
      else { out[i*4]=data[i*4]; out[i*4+1]=data[i*4+1]; out[i*4+2]=data[i*4+2]; out[i*4+3]=80; maskedPix++; }
    }
    if(canvasRef.current){ canvasRef.current.width=w; canvasRef.current.height=h; const v=canvasRef.current.getContext("2d")!; v.putImageData(new ImageData(out,w,h),0,0); }

    // collect kept pixels
    const keep=new Uint8ClampedArray(used*4); for(let i=0,j=0;i<w*h;i++){ if(finalMask[i]===255){ keep[j++]=data[i*4]; keep[j++]=data[i*4+1]; keep[j++]=data[i*4+2]; keep[j++]=255; } }

    // auto-K via GMM+BIC (in Lab ab space for perceptual grouping) -> but compute on RGB for speed fallback
    let clusters:Cluster[];
    if(autoK){
      const pts:number[][]=[];
      for(let i=0;i<keep.length;i+=4){ pts.push([keep[i],keep[i+1],keep[i+2]]); }
      const best=gmmDiagBIC(pts,3,8,20);
      clusters=kmeansRGB(keep, best.k, 25, true);
    } else {
      clusters=kmeansRGB(keep, k, 25, true);
    }

    // stats
    const hues:number[]=[], sats:number[]=[], vals:number[]=[], Ls:number[]=[], As:number[]=[], Bs:number[]=[], hueHist=new Array(360).fill(0);
    // choose white point: D65 default; if useD50 => adapt; if icc WP -> use that
    let white:[number,number,number]=[0.95047,1.0,1.08883];
    if(useD50) white=[0.96422,1.0,0.82521];
    if(iccWP) white=iccWP;
    for(let i=0;i<keep.length;i+=4){
      const r=keep[i], g=keep[i+1], b=keep[i+2];
      const h1=rgbToHsv(r,g,b); hues.push(h1[0]); sats.push(h1[1]); vals.push(h1[2]); hueHist[Math.floor(h1[0])%360]++;
      const lab=rgbToLab(r,g,b,white); Ls.push(lab.L); As.push(lab.a); Bs.push(lab.b);
    }
    const mean=(arr:number[])=>arr.reduce((a,b)=>a+b,0)/Math.max(1,arr.length);
    const sorted=(arr:number[])=>arr.slice().sort((a,b)=>a-b);
    const med=(arr:number[])=>{ const s=sorted(arr); const m=Math.floor(s.length/2); return s.length%2?s[m]:(s[m-1]+s[m])/2; };

    const circ=circularStatsDeg(hues); const hb=hueBorderlineFromHist(hueHist,3); const cat=softCategory(circ.mean);
    const abSamples:[number,number][]=[]; const step=Math.max(1,Math.floor(As.length/2000)); for(let i=0;i<As.length;i+=step){ abSamples.push([As[i],Bs[i]]); }

    const refLab=rgbToLab(...hexToRgb(refHex), white); const meanLab:Lab={L:mean(Ls),a:mean(As),b:mean(Bs)};
    const dE76=deltaE76(meanLab,refLab), dE2000=deltaE2000(meanLab,refLab);

    setAnalysis({
      width:w,height:h,totalPixels:w*h,usedPixels:used,maskRatio:maskedPix/(w*h),k:autoK?clusters.length:k, clusters,
      hsvStats:{ hueMean:mean(hues), satMean:mean(sats), valMean:mean(vals), hueMedian:med(hues), satMedian:med(sats), valMedian:med(vals) },
      labStats:{ Lmean:mean(Ls), aMean:mean(As), bMean:mean(Bs), Lmedian:med(Ls), aMedian:med(As), bMedian:med(Bs) },
      refDeltaE:{ hex:refHex, dE76, dE2000 },
      hue:{ mean:circ.mean, R:circ.R, circVar:circ.circVar, sepDeg:hb.sepDeg, category:{ primary:cat.primary, secondary:cat.secondary, conf:cat.conf, borderline:cat.borderline } },
      hueHist, abSamples,
      params:{ autoK, slicStep, slicM, guidedR, guidedEps, white }
    });
  },[url,k,autoK,scale,maskWhite,maskBlack,maskLowSat,smartMask,whiteThr,blackThr,satThr,refHex,useD50,iccWP,slicStep,slicM,guidedR,guidedEps]);

  const exportPDF = useCallback(async ()=>{
    if(!analysis) return; const { default: jsPDF } = await import("jspdf"); const doc = new jsPDF({ unit: "pt", format: "a4" });
    doc.setFont("helvetica","bold"); doc.text("Gem Photo Color Analysis – Borderline Pro", 40, 40);
    doc.setFont("helvetica","normal");
    doc.text(`Size ${analysis.width}×${analysis.height}  Used ${analysis.usedPixels}/${analysis.totalPixels}  Mask ${(analysis.maskRatio*100).toFixed(1)}%`, 40, 66);
    let y=92; doc.text(`K = ${analysis.k} (auto=${analysis.params.autoK? "on":"off"})`, 40, y); y+=20;
    analysis.clusters.forEach((c:any,i:number)=>{ doc.setFillColor(c.rgb[0],c.rgb[1],c.rgb[2]); doc.rect(40,y-12,18,18,"F"); doc.text(`${i+1}. ${c.hex}  H:${c.hsv[0].toFixed(1)} S:${c.hsv[1].toFixed(1)} V:${c.hsv[2].toFixed(1)}  ${(c.share*100).toFixed(1)}%`, 68, y); y+=24; });
    y+=6; doc.text(`HSV ⌀  H ${analysis.hsvStats.hueMean.toFixed(1)}°  S ${analysis.hsvStats.satMean.toFixed(1)}%  V ${analysis.hsvStats.valMean.toFixed(1)}%`, 40, y);
    y+=18; doc.text(`Lab ⌀  L* ${analysis.labStats.Lmean.toFixed(1)}  a* ${analysis.labStats.aMean.toFixed(1)}  b* ${analysis.labStats.bMean.toFixed(1)}`, 40, y);
    y+=18; doc.text(`ΔE76 ${analysis.refDeltaE.dE76.toFixed(2)}  ΔE2000 ${analysis.refDeltaE.dE2000.toFixed(2)} vs ${analysis.refDeltaE.hex}`, 40, y);
    const cvs = canvasRef.current; if(cvs){ const dataUrl=cvs.toDataURL("image/jpeg",0.9); doc.addImage(dataUrl,"JPEG", 320, 40, 250, 250*(cvs.height/cvs.width)); }
    y+=28; doc.text(`Borderline: ${analysis.hue.category.borderline ? "Ja" : "Nein"}  | Hue ⌀ ${analysis.hue.mean.toFixed(1)}°  R ${analysis.hue.R.toFixed(2)}  Peak Δ ${analysis.hue.sepDeg.toFixed(1)}°  KonfΔ ${analysis.hue.category.conf.toFixed(2)}`, 40, y);
    y+=18; doc.text(`Kategorie: ${analysis.hue.category.primary.name}${analysis.hue.category.secondary? " / "+analysis.hue.category.secondary.name:""}`, 40, y);
    // Params
    y+=22; doc.text(`Params: AutoK ${analysis.params.autoK}, SLIC step ${analysis.params.slicStep}, m ${analysis.params.slicM}, Guided r ${analysis.params.guidedR}, eps ${analysis.params.guidedEps.toExponential(1)}`, 40, y);
    y+=18; doc.text(`White: Xr ${analysis.params.white[0].toFixed(5)} Yr ${analysis.params.white[1].toFixed(5)} Zr ${analysis.params.white[2].toFixed(5)}`, 40, y);
    doc.save("gem-photo-color-analysis-borderline-pro.pdf");
  },[analysis]);

  // JSON/CSV export of Borderline report
  const exportJSON = useCallback(()=>{
    if(!analysis) return;
    const blob = new Blob([JSON.stringify(analysis,null,2)], {type:"application/json"});
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download="borderline-report.json"; a.click(); URL.revokeObjectURL(url);
  },[analysis]);
  const exportCSV = useCallback(()=>{
    if(!analysis) return;
    const c=analysis.clusters; const c1=c[0]||{}, c2=c[1]||{}, c3=c[2]||{};
    const header="k,hueMean,satMean,valMean,Lmean,aMean,bMean,dE76,dE2000,primary,secondary,conf,borderline,top1,share1,top2,share2,top3,share3\n";
    const line=[
      analysis.k,
      analysis.hsvStats.hueMean.toFixed(2),
      analysis.hsvStats.satMean.toFixed(2),
      analysis.hsvStats.valMean.toFixed(2),
      analysis.labStats.Lmean.toFixed(2),
      analysis.labStats.aMean.toFixed(2),
      analysis.labStats.bMean.toFixed(2),
      analysis.refDeltaE.dE76.toFixed(2),
      analysis.refDeltaE.dE2000.toFixed(2),
      analysis.hue.category.primary?.name ?? "",
      analysis.hue.category.secondary?.name ?? "",
      analysis.hue.category.conf.toFixed(3),
      analysis.hue.category.borderline ? "1":"0",
      c1.hex||"", (c1.share*100||0).toFixed(1)+"%",
      c2.hex||"", (c2.share*100||0).toFixed(1)+"%",
      c3.hex||"", (c3.share*100||0).toFixed(1)+"%"
    ].join(",");
    const blob=new Blob([header+line+"\n"], {type:"text/csv"});
    const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download="borderline-report.csv"; a.click(); URL.revokeObjectURL(url);
  },[analysis]);

  return (
    <div className="mx-auto max-w-6xl p-4">
      <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-gray-900 mb-1">Edelsteinfoto – Farb-Analyse (Borderline Pro)</h1>
      <p className="text-sm text-gray-600 mb-4">Auto-K (GMM+BIC), K-Means++, SLIC+Guided-Filter, ICC-Upload & D50, Grenzfarb-Erkennung, ΔE.</p>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="rounded-2xl border p-4">
          <h3 className="font-semibold mb-3">Upload</h3>
          <div className="space-y-2 text-sm">
            <div onDragOver={(e)=>e.preventDefault()} onDrop={onDrop} className="rounded-xl border border-dashed p-3 text-center">
              <input id="file" type="file" accept="image/*" className="hidden" onChange={onInput} />
              <label htmlFor="file" className="cursor-pointer inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border shadow-sm bg-gray-50 hover:bg-gray-100">
                <span>Bild auswählen</span>
              </label>
              <div className="mt-1 text-xs text-gray-500">oder per Drag & Drop …</div>
              {file && <div className="mt-1 text-xs text-gray-600">{file.name}</div>}
            </div>
            <div className="text-xs text-gray-600">
              ICC-Profil (optional): <input id="icc" type="file" accept=".icc,.icm" onChange={onICC} />
              {iccInfo && <div className="mt-1">wtpt: {iccInfo.wtpt? iccInfo.wtpt.map((x:number)=>x.toFixed(5)).join(", "):"—"}</div>}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border p-4">
          <h3 className="font-semibold mb-3">Maskierung</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" checked={maskWhite} onChange={(e)=>setMaskWhite(e.target.checked)} /> Helle/entsättigte</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={maskBlack} onChange={(e)=>setMaskBlack(e.target.checked)} /> Sehr dunkle</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={maskLowSat} onChange={(e)=>setMaskLowSat(e.target.checked)} /> Niedrige Sättigung</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={smartMask} onChange={(e)=>setSmartMask(e.target.checked)} /> Smart Mask</label>
            <div className="flex items-center gap-2 col-span-2">
              <span className="w-40">Weiß-Schwelle (Luma)</span>
              <input type="range" min={180} max={250} value={whiteThr} onChange={(e)=>setWhiteThr(parseInt(e.target.value))} className="w-full" />
              <span className="w-10 text-right">{whiteThr}</span>
            </div>
            <div className="flex items-center gap-2 col-span-2">
              <span className="w-40">Schwarz-Schwelle (Luma)</span>
              <input type="range" min={0} max={60} value={blackThr} onChange={(e)=>setBlackThr(parseInt(e.target.value))} className="w-full" />
              <span className="w-10 text-right">{blackThr}</span>
            </div>
            <div className="flex items-center gap-2 col-span-2">
              <span className="w-40">Sättigungs-Schwelle (S%)</span>
              <input type="range" min={0} max={30} value={satThr} onChange={(e)=>setSatThr(parseInt(e.target.value))} className="w-full" />
              <span className="w-10 text-right">{satThr}</span>
            </div>
            <div className="col-span-2 grid grid-cols-2 gap-3 mt-2">
              <div>
                <div className="text-xs">SLIC Step</div>
                <input type="range" min={8} max={40} value={slicStep} onChange={(e)=>setSlicStep(parseInt(e.target.value))} className="w-full" />
              </div>
              <div>
                <div className="text-xs">SLIC m</div>
                <input type="range" min={5} max={30} value={slicM} onChange={(e)=>setSlicM(parseInt(e.target.value))} className="w-full" />
              </div>
              <div>
                <div className="text-xs">Guided r</div>
                <input type="range" min={2} max={16} value={guidedR} onChange={(e)=>setGuidedR(parseInt(e.target.value))} className="w-full" />
              </div>
              <div>
                <div className="text-xs">Guided eps</div>
                <input type="range" min={-6} max={-2} value={Math.log10(guidedEps)} onChange={(e)=>setGuidedEps(10**parseInt(e.target.value))} className="w-full" />
                <div className="text-xs text-gray-500">10^{Math.round(Math.log10(guidedEps))}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border p-4">
          <h3 className="font-semibold mb-3">Farbe / Referenz</h3>
          <div className="mb-2 flex items-center gap-3 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" checked={useServer} onChange={(e)=>setUseServer(e.target.checked)} /> Serverseitige Analyse-API</label>
            <div className="flex items-center gap-2">
              <span>Algorithmus</span>
              <select value={algo} onChange={(e)=>setAlgo(e.target.value as any)} className="border rounded px-2 py-1">
                <option value="auto">Auto (GMM+BIC → K-Means++)</option>
                <option value="kmeans">K-Means++ (K manuell)</option>
                <option value="gmm">GMM (fixes K → K-Means++)</option>
              </select>
            </div>
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between gap-3">
              <label className="min-w-32">Cluster (K)</label>
              <input type="range" min={3} max={10} value={k} onChange={(e)=>setK(parseInt(e.target.value))} disabled={autoK} className="w-full" />
              <div className="w-10 text-right font-medium">{autoK? "auto" : k}</div>
            </div>
            <label className="flex items-center gap-2"><input type="checkbox" checked={autoK} onChange={(e)=>setAutoK(e.target.checked)} /> Auto-K (GMM+BIC)</label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={useD50} onChange={(e)=>setUseD50(e.target.checked)} /> D50 (Bradford)</label>
            <div className="flex items-center gap-2">
              <span className="w-28">Referenz HEX</span>
              <input value={refHex} onChange={(e)=>setRefHex(e.target.value)} className="border rounded px-2 py-1 w-32" />
              <div className="h-6 w-6 rounded border" style={{ backgroundColor: refHex }} />
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <button onClick={run} disabled={!url} className="px-4 py-2 rounded-xl border bg-indigo-600 text-white disabled:opacity-50 shadow">Analyse starten</button>
        <button onClick={exportPDF} disabled={!analysis} className="px-4 py-2 rounded-xl border bg-white disabled:opacity-50 shadow">PDF</button>
        <button onClick={exportJSON} disabled={!analysis} className="px-4 py-2 rounded-xl border bg-white disabled:opacity-50 shadow">JSON</button>
        <button onClick={exportCSV} disabled={!analysis} className="px-4 py-2 rounded-xl border bg-white disabled:opacity-50 shadow">CSV</button>
      </div>

      <div className="grid md:grid-cols-2 gap-6 items-start">
        <div className="rounded-2xl border overflow-hidden">
          <div className="p-3 text-sm text-gray-700 flex items-center justify-between">
            <span>Maskierte Vorschau</span>
            <span className="text-xs text-gray-500">Canvas {analysis?.width ?? "–"}×{analysis?.height ?? "–"}</span>
          </div>
          {serverPreview ? (
            <img src={serverPreview} className="block w-full h-auto" />
          ) : (
            <canvas ref={canvasRef} className="block w-full h-auto"/>
          )}
        </div>

        <div className="space-y-4">
          {analysis ? (
            <>
              <div className="rounded-2xl border p-4 text-sm">
                <div className="flex flex-wrap gap-3">
                  <span><b>Pixels genutzt:</b> {analysis.usedPixels.toLocaleString()} / {analysis.totalPixels.toLocaleString()}</span>
                  <span><b>Maskiert:</b> {(analysis.maskRatio*100).toFixed(1)}%</span>
                  <span><b>K:</b> {analysis.k}</span>
                  <span><b>ΔE2000 vs {analysis.refDeltaE.hex}:</b> {analysis.refDeltaE.dE2000.toFixed(2)}</span>
                </div>
              </div>

              <div className="rounded-2xl border p-4">
                <h3 className="font-semibold mb-3">Dominante Farben</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {analysis.clusters.map((c:any,i:number)=> (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-2xl border bg-white/50 shadow-sm">
                      <div className="h-10 w-10 rounded-xl border" style={{ backgroundColor: c.hex }} />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-gray-900">{c.hex}</div>
                        <div className="text-xs text-gray-600">RGB {c.rgb.join(", ")} • HSV {c.hsv.map((v:number)=>v.toFixed(1)).join(", ")} • Anteil {(c.share*100).toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4">
                  <div className="text-xs text-gray-600 mb-1">Clusteranteile</div>
                  <div className="flex items-end gap-2 h-28">
                    {analysis.clusters.map((c:any,i:number)=> (
                      <div key={i} className="flex flex-col items-center gap-1">
                        <div className="w-8 rounded-t-md shadow" style={{ height: `${Math.max(6, c.share*100)}%`, backgroundColor: c.hex }} />
                        <div className="text-[10px] text-gray-600">{Math.round(c.share*100)}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border p-4 text-sm">
                <h3 className="font-semibold mb-2">Helligkeit & Sättigung (HSV)</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div>Hue ⌀: <b>{analysis.hsvStats.hueMean.toFixed(1)}°</b></div>
                  <div>Hue Median: <b>{analysis.hsvStats.hueMedian.toFixed(1)}°</b></div>
                  <div>Sat ⌀: <b>{analysis.hsvStats.satMean.toFixed(1)}%</b></div>
                  <div>Sat Median: <b>{analysis.hsvStats.satMedian.toFixed(1)}%</b></div>
                  <div>Value ⌀: <b>{analysis.hsvStats.valMean.toFixed(1)}%</b></div>
                  <div>Value Median: <b>{analysis.hsvStats.valMedian.toFixed(1)}%</b></div>
                </div>
              </div>

              <div className="rounded-2xl border p-4 text-sm">
                <h3 className="font-semibold mb-2">CIE L*a*b* & ΔE</h3>
                <div className="grid grid-cols-3 gap-2">
                  <div>L* ⌀: <b>{analysis.labStats.Lmean.toFixed(2)}</b></div>
                  <div>a* ⌀: <b>{analysis.labStats.aMean.toFixed(2)}</b></div>
                  <div>b* ⌀: <b>{analysis.labStats.bMean.toFixed(2)}</b></div>
                  <div>L* Median: <b>{analysis.labStats.Lmedian.toFixed(2)}</b></div>
                  <div>a* Median: <b>{analysis.labStats.aMedian.toFixed(2)}</b></div>
                  <div>b* Median: <b>{analysis.labStats.bMedian.toFixed(2)}</b></div>
                </div>
              </div>

              {/* Borderline */}
              <div className="rounded-2xl border p-4 text-sm">
                <h3 className="font-semibold mb-2">Grenzbereichs-Analyse</h3>
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span>Hue ⌀: <b>{analysis.hue.mean.toFixed(1)}°</b></span>
                  <span>R (Kompaktheit): <b>{analysis.hue.R.toFixed(2)}</b></span>
                  <span>Peak-Abstand: <b>{analysis.hue.sepDeg.toFixed(1)}°</b></span>
                  {analysis.hue.category.borderline ? (
                    <span className="inline-flex items-center px-2 py-1 rounded bg-amber-100 text-amber-800 border border-amber-300">
                      Borderline: {analysis.hue.category.primary.name} / {analysis.hue.category.secondary?.name}
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2 py-1 rounded bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Klar: {analysis.hue.category.primary.name}
                    </span>
                  )}
                  <span>KonfidenzΔ: <b>{analysis.hue.category.conf.toFixed(2)}</b></span>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-gray-600 mb-1">Hue-Histogramm (0–360°)</div>
                    <div className="flex items-end gap-[1px] h-28 bg-gray-50 rounded p-1 border">
                      {analysis.hueHist.map((v:number,i:number)=>{
                        const vmax = Math.max(1, ...analysis.hueHist as number[]);
                        const h = Math.round((v/vmax)*100);
                        return <div key={i} style={{height: `${h}%`}} className="w-[1px] bg-gray-700" />;
                      })}
                    </div>
                  </div>
                  <div className="overflow-hidden rounded border bg-white">
                    <div className="text-xs text-gray-600 p-1">a* vs b* (decimated)</div>
                    <svg viewBox="-120 -120 240 240" className="w-full h-40">
                      <rect x="-120" y="-120" width="240" height="240" fill="white" />
                      <line x1="-120" y1="0" x2="120" y2="0" stroke="#ddd" />
                      <line x1="0" y1="-120" x2="0" y2="120" stroke="#ddd" />
                      {analysis.abSamples.map((p:[number,number],i:number)=> <circle key={i} cx={p[0]} cy={-p[1]} r="0.8" fill="black" opacity="0.6" />)}
                    </svg>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="rounded-2xl border p-6 text-sm text-gray-600">
              Noch keine Analyse. Lade ein Bild hoch und klicke auf <b>Analyse starten</b>.
            </div>
          )}
        </div>
      </div>

      {url && (
        <div className="mt-6 grid md:grid-cols-2 gap-6 items-start">
          <div className="rounded-2xl border overflow-hidden">
            <div className="p-3 text-sm text-gray-700">Originalbild</div>
            <img ref={origRef} src={url} alt="upload preview" className="block w-full h-auto" />
          </div>
        </div>
      )}

      <footer className="pt-8 text-xs text-gray-500">
        Hinweis: Visuell angenähert; ersetzt keine instrumentelle Spektralanalyse. Für präzise Messungen Laborgeräte verwenden.
      </footer>
    </div>
  );
}